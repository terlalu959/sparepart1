package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Entitas Inventaris Sparepart Bengkel Bus dengan kode barcode/QR.
 */
@Entity(
    tableName = "spareparts",
    indices = [Index(value = ["partCode"], unique = true)]
)
data class SparepartEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val partCode: String,         // Kode part / Barcode, e.g. "BRK-PAD-01", "OIL-FLT-1626"
    val name: String,             // Nama sparepart, e.g. "Kampas Rem Depan Heavy Duty"
    val category: String,         // "Pengereman", "Mesin & Pelumas", "Suspensi & Balon", "Kelistrikan", "Filter", "Transmisi"
    val stock: Int,               // Jumlah stok fisik saat ini
    val minStock: Int = 2,        // Batas minimal stok untuk pengingat/alert
    val unit: String = "Pcs",     // Satuan: Pcs, Set, Liter, Box
    val unitPrice: Double,        // Harga per satuan (Rp)
    val shelfLocation: String,    // Lokasi Rak, e.g. "Rak A-03", "Gudang Oli B-1"
    val updatedAt: Long = System.currentTimeMillis()
)
