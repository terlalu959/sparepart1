package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.SparepartEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SparepartDao {
    @Query("SELECT * FROM spareparts ORDER BY name ASC")
    fun getAllSpareparts(): Flow<List<SparepartEntity>>

    @Query("SELECT * FROM spareparts WHERE id = :id LIMIT 1")
    suspend fun getSparepartById(id: Long): SparepartEntity?

    @Query("SELECT * FROM spareparts WHERE partCode = :code LIMIT 1")
    suspend fun getSparepartByCode(code: String): SparepartEntity?

    @Query("SELECT * FROM spareparts WHERE partCode = :code LIMIT 1")
    fun getSparepartByCodeFlow(code: String): Flow<SparepartEntity?>

    @Query("SELECT * FROM spareparts WHERE partCode LIKE '%' || :query || '%' OR name LIKE '%' || :query || '%' ORDER BY name ASC")
    fun searchSpareparts(query: String): Flow<List<SparepartEntity>>

    @Query("SELECT * FROM spareparts WHERE category = :category ORDER BY name ASC")
    fun getSparepartsByCategory(category: String): Flow<List<SparepartEntity>>

    @Query("SELECT * FROM spareparts WHERE stock <= minStock ORDER BY stock ASC")
    fun getLowStockSpareparts(): Flow<List<SparepartEntity>>

    @Query("SELECT COUNT(*) FROM spareparts WHERE stock <= minStock")
    fun getLowStockCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM spareparts")
    fun getTotalPartCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSparepart(sparepart: SparepartEntity): Long

    @Update
    suspend fun updateSparepart(sparepart: SparepartEntity)

    @Delete
    suspend fun deleteSparepart(sparepart: SparepartEntity)

    @Query("DELETE FROM spareparts WHERE id = :id")
    suspend fun deleteSparepartById(id: Long)

    @Query("UPDATE spareparts SET stock = stock - :amount, updatedAt = :updatedAt WHERE id = :id AND stock >= :amount")
    suspend fun decreaseStock(id: Long, amount: Int, updatedAt: Long = System.currentTimeMillis()): Int

    @Query("UPDATE spareparts SET stock = stock + :amount, updatedAt = :updatedAt WHERE id = :id")
    suspend fun increaseStock(id: Long, amount: Int, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE spareparts SET stock = :newStock, updatedAt = :updatedAt WHERE id = :id")
    suspend fun setStock(id: Long, newStock: Int, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM spareparts")
    suspend fun deleteAll()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(spareparts: List<SparepartEntity>)
}
