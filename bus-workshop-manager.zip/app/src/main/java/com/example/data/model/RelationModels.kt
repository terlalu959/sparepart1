package com.example.data.model

import androidx.room.Embedded
import androidx.room.Relation
import com.example.data.local.entity.BusEntity
import com.example.data.local.entity.MechanicEntity
import com.example.data.local.entity.PartUsageEntity
import com.example.data.local.entity.ServiceOrderEntity
import com.example.data.local.entity.SparepartEntity

/**
 * Item pemakaian part dengan detail data sparepart (nama, kode, unit).
 */
data class PartUsageDetail(
    val id: Long,
    val serviceOrderId: Long,
    val sparepartId: Long,
    val busId: Long,
    val quantity: Int,
    val unitPrice: Double,
    val subtotal: Double,
    val dateUsed: Long,
    val notes: String,
    val partName: String,
    val partCode: String,
    val partUnit: String,
    val shelfLocation: String
)

/**
 * Service order lengkap dengan data Bus, Mekanik, dan part yang dipakai.
 */
data class ServiceOrderDetail(
    val serviceOrder: ServiceOrderEntity,
    val bus: BusEntity?,
    val mechanic: MechanicEntity?,
    val partsUsed: List<PartUsageDetail> = emptyList()
)

/**
 * Ringkasan pemakaian part untuk laporan/rekap.
 */
data class PartUsageSummary(
    val sparepartId: Long,
    val partCode: String,
    val partName: String,
    val category: String,
    val totalQuantity: Int,
    val totalCost: Double,
    val unit: String
)

/**
 * Ringkasan statistik bengkel bus.
 */
data class WorkshopStats(
    val totalBuses: Int = 0,
    val activeBuses: Int = 0,
    val inWorkshopBuses: Int = 0,
    val activeServiceOrders: Int = 0,
    val completedServiceOrders: Int = 0,
    val lowStockPartsCount: Int = 0,
    val totalPartInventoryCount: Int = 0,
    val totalExpensesThisMonth: Double = 0.0
)
