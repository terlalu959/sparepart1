package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.BusDao
import com.example.data.local.dao.MechanicDao
import com.example.data.local.dao.PartUsageDao
import com.example.data.local.dao.ServiceOrderDao
import com.example.data.local.dao.SparepartDao
import com.example.data.local.entity.BusEntity
import com.example.data.local.entity.MechanicEntity
import com.example.data.local.entity.PartUsageEntity
import com.example.data.local.entity.ServiceOrderEntity
import com.example.data.local.entity.SparepartEntity

@Database(
    entities = [
        BusEntity::class,
        MechanicEntity::class,
        SparepartEntity::class,
        ServiceOrderEntity::class,
        PartUsageEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun busDao(): BusDao
    abstract fun mechanicDao(): MechanicDao
    abstract fun sparepartDao(): SparepartDao
    abstract fun serviceOrderDao(): ServiceOrderDao
    abstract fun partUsageDao(): PartUsageDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "bengkel_bus_database.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
