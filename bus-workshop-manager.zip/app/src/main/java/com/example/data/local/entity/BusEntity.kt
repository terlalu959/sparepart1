package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entitas Unit Bus untuk manajemen armada bengkel bus.
 */
@Entity(tableName = "buses")
data class BusEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val plateNumber: String,      // Nomor Polisi, e.g. "B 7123 VGA"
    val model: String,            // Model Bus & Karoseri, e.g. "Mercedes-Benz OH 1626 / Jetbus 3+ HDD"
    val year: Int,                // Tahun Pembuatan, e.g. 2021
    val lastOdometer: Int,        // Kilometer Terakhir, e.g. 145200
    val serviceStatus: String,    // "Siap Jalan", "Dalam Perbaikan", "Perlu Servis", "Perbaikan Berat"
    val operatorName: String = "PO Primadona Trans", // Nama PO / Operator
    val notes: String = "",       // Catatan khusus unit
    val updatedAt: Long = System.currentTimeMillis()
)
