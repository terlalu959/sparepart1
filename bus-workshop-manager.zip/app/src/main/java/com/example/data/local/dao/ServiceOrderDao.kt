package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.ServiceOrderEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ServiceOrderDao {
    @Query("SELECT * FROM service_orders ORDER BY entryDate DESC")
    fun getAllServiceOrders(): Flow<List<ServiceOrderEntity>>

    @Query("SELECT * FROM service_orders WHERE id = :id LIMIT 1")
    suspend fun getServiceOrderById(id: Long): ServiceOrderEntity?

    @Query("SELECT * FROM service_orders WHERE id = :id LIMIT 1")
    fun getServiceOrderByIdFlow(id: Long): Flow<ServiceOrderEntity?>

    @Query("SELECT * FROM service_orders WHERE busId = :busId ORDER BY entryDate DESC")
    fun getServiceOrdersByBusId(busId: Long): Flow<List<ServiceOrderEntity>>

    @Query("SELECT * FROM service_orders WHERE status != 'Selesai' AND status != 'Batal' ORDER BY entryDate DESC")
    fun getActiveServiceOrders(): Flow<List<ServiceOrderEntity>>

    @Query("SELECT * FROM service_orders WHERE status = :status ORDER BY entryDate DESC")
    fun getServiceOrdersByStatus(status: String): Flow<List<ServiceOrderEntity>>

    @Query("SELECT COUNT(*) FROM service_orders WHERE status != 'Selesai' AND status != 'Batal'")
    fun getActiveServiceOrdersCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM service_orders WHERE status = 'Selesai'")
    fun getCompletedServiceOrdersCount(): Flow<Int>

    @Query("SELECT * FROM service_orders WHERE entryDate BETWEEN :startDate AND :endDate ORDER BY entryDate DESC")
    fun getServiceOrdersBetweenDates(startDate: Long, endDate: Long): Flow<List<ServiceOrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServiceOrder(order: ServiceOrderEntity): Long

    @Update
    suspend fun updateServiceOrder(order: ServiceOrderEntity)

    @Delete
    suspend fun deleteServiceOrder(order: ServiceOrderEntity)

    @Query("DELETE FROM service_orders WHERE id = :id")
    suspend fun deleteServiceOrderById(id: Long)

    @Query("UPDATE service_orders SET totalPartCost = :cost, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateTotalPartCost(id: Long, cost: Double, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE service_orders SET status = :status, exitDate = :exitDate, repairNotes = :notes, updatedAt = :updatedAt WHERE id = :id")
    suspend fun completeServiceOrder(
        id: Long,
        status: String = "Selesai",
        exitDate: Long = System.currentTimeMillis(),
        notes: String,
        updatedAt: Long = System.currentTimeMillis()
    )

    @Query("DELETE FROM service_orders")
    suspend fun deleteAll()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(orders: List<ServiceOrderEntity>)
}
