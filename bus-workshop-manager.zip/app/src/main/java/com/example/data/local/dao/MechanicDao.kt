package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.MechanicEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MechanicDao {
    @Query("SELECT * FROM mechanics ORDER BY name ASC")
    fun getAllMechanics(): Flow<List<MechanicEntity>>

    @Query("SELECT * FROM mechanics WHERE id = :id LIMIT 1")
    suspend fun getMechanicById(id: Long): MechanicEntity?

    @Query("SELECT * FROM mechanics WHERE status = 'Aktif' ORDER BY name ASC")
    fun getActiveMechanics(): Flow<List<MechanicEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMechanic(mechanic: MechanicEntity): Long

    @Update
    suspend fun updateMechanic(mechanic: MechanicEntity)

    @Delete
    suspend fun deleteMechanic(mechanic: MechanicEntity)

    @Query("DELETE FROM mechanics WHERE id = :id")
    suspend fun deleteMechanicById(id: Long)

    @Query("DELETE FROM mechanics")
    suspend fun deleteAll()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(mechanics: List<MechanicEntity>)
}
