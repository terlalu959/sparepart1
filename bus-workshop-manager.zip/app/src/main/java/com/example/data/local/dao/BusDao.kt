package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.BusEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BusDao {
    @Query("SELECT * FROM buses ORDER BY plateNumber ASC")
    fun getAllBuses(): Flow<List<BusEntity>>

    @Query("SELECT * FROM buses WHERE id = :id LIMIT 1")
    suspend fun getBusById(id: Long): BusEntity?

    @Query("SELECT * FROM buses WHERE id = :id LIMIT 1")
    fun getBusByIdFlow(id: Long): Flow<BusEntity?>

    @Query("SELECT * FROM buses WHERE plateNumber LIKE '%' || :query || '%' OR model LIKE '%' || :query || '%' ORDER BY plateNumber ASC")
    fun searchBuses(query: String): Flow<List<BusEntity>>

    @Query("SELECT * FROM buses WHERE serviceStatus = :status ORDER BY plateNumber ASC")
    fun getBusesByStatus(status: String): Flow<List<BusEntity>>

    @Query("SELECT COUNT(*) FROM buses")
    fun getBusCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBus(bus: BusEntity): Long

    @Update
    suspend fun updateBus(bus: BusEntity)

    @Delete
    suspend fun deleteBus(bus: BusEntity)

    @Query("DELETE FROM buses WHERE id = :id")
    suspend fun deleteBusById(id: Long)

    @Query("UPDATE buses SET lastOdometer = :odometer, serviceStatus = :status, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateBusStatusAndOdometer(id: Long, status: String, odometer: Int, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM buses")
    suspend fun deleteAll()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(buses: List<BusEntity>)
}
