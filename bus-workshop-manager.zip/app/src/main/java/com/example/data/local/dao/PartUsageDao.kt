package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.PartUsageEntity
import com.example.data.model.PartUsageDetail
import com.example.data.model.PartUsageSummary
import kotlinx.coroutines.flow.Flow

@Dao
interface PartUsageDao {
    @Query("SELECT * FROM part_usages ORDER BY dateUsed DESC")
    fun getAllUsages(): Flow<List<PartUsageEntity>>

    @Query("SELECT * FROM part_usages WHERE id = :id LIMIT 1")
    suspend fun getUsageById(id: Long): PartUsageEntity?

    @Query("""
        SELECT 
            pu.id,
            pu.serviceOrderId,
            pu.sparepartId,
            pu.busId,
            pu.quantity,
            pu.unitPrice,
            pu.subtotal,
            pu.dateUsed,
            pu.notes,
            sp.name AS partName,
            sp.partCode AS partCode,
            sp.unit AS partUnit,
            sp.shelfLocation AS shelfLocation
        FROM part_usages pu
        INNER JOIN spareparts sp ON pu.sparepartId = sp.id
        WHERE pu.serviceOrderId = :serviceOrderId
        ORDER BY pu.dateUsed DESC
    """)
    fun getUsageDetailsByServiceOrder(serviceOrderId: Long): Flow<List<PartUsageDetail>>

    @Query("""
        SELECT 
            pu.id,
            pu.serviceOrderId,
            pu.sparepartId,
            pu.busId,
            pu.quantity,
            pu.unitPrice,
            pu.subtotal,
            pu.dateUsed,
            pu.notes,
            sp.name AS partName,
            sp.partCode AS partCode,
            sp.unit AS partUnit,
            sp.shelfLocation AS shelfLocation
        FROM part_usages pu
        INNER JOIN spareparts sp ON pu.sparepartId = sp.id
        WHERE pu.busId = :busId
        ORDER BY pu.dateUsed DESC
    """)
    fun getUsageDetailsByBus(busId: Long): Flow<List<PartUsageDetail>>

    @Query("SELECT SUM(subtotal) FROM part_usages WHERE serviceOrderId = :serviceOrderId")
    suspend fun getTotalPartCostForServiceOrder(serviceOrderId: Long): Double?

    @Query("""
        SELECT 
            pu.sparepartId,
            sp.partCode,
            sp.name AS partName,
            sp.category,
            SUM(pu.quantity) AS totalQuantity,
            SUM(pu.subtotal) AS totalCost,
            sp.unit
        FROM part_usages pu
        INNER JOIN spareparts sp ON pu.sparepartId = sp.id
        WHERE pu.dateUsed BETWEEN :startDate AND :endDate
        GROUP BY pu.sparepartId
        ORDER BY totalCost DESC
    """)
    fun getPartUsageSummaries(startDate: Long, endDate: Long): Flow<List<PartUsageSummary>>

    @Query("SELECT SUM(subtotal) FROM part_usages WHERE dateUsed BETWEEN :startDate AND :endDate")
    fun getTotalPartExpenses(startDate: Long, endDate: Long): Flow<Double?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUsage(usage: PartUsageEntity): Long

    @Update
    suspend fun updateUsage(usage: PartUsageEntity)

    @Delete
    suspend fun deleteUsage(usage: PartUsageEntity)

    @Query("DELETE FROM part_usages WHERE id = :id")
    suspend fun deleteUsageById(id: Long)

    @Query("DELETE FROM part_usages")
    suspend fun deleteAll()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(usages: List<PartUsageEntity>)
}
