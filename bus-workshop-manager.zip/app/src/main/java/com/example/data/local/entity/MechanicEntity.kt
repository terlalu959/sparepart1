package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entitas Mekanik Bengkel Bus.
 */
@Entity(tableName = "mechanics")
data class MechanicEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,             // Nama Mekanik, e.g. "Bambang Sudiro"
    val specialization: String,   // Keahlian, e.g. "Mesin & Transmisi", "Sistem Rem & Suspensi", "AC & Kelistrikan"
    val phone: String,            // Nomor Kontak/HP
    val status: String = "Aktif", // "Aktif", "Sedang Bertugas", "Cuti"
    val joinedYear: Int = 2020,
    val updatedAt: Long = System.currentTimeMillis()
)
