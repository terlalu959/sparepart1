package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.local.entity.BusEntity
import com.example.data.local.entity.MechanicEntity
import com.example.data.local.entity.PartUsageEntity
import com.example.data.local.entity.ServiceOrderEntity
import com.example.data.local.entity.SparepartEntity
import com.example.data.model.PartUsageDetail
import com.example.data.model.PartUsageSummary
import com.example.data.model.ServiceOrderDetail
import com.example.data.model.WorkshopStats
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

class WorkshopRepository(private val database: AppDatabase) {
    private val busDao = database.busDao()
    private val mechanicDao = database.mechanicDao()
    private val sparepartDao = database.sparepartDao()
    private val serviceOrderDao = database.serviceOrderDao()
    private val partUsageDao = database.partUsageDao()

    // ==========================================
    // BUS OPERATIONS
    // ==========================================
    fun getAllBuses(): Flow<List<BusEntity>> = busDao.getAllBuses()

    suspend fun getBusById(id: Long): BusEntity? = busDao.getBusById(id)

    fun searchBuses(query: String): Flow<List<BusEntity>> {
        return if (query.isBlank()) busDao.getAllBuses() else busDao.searchBuses(query)
    }

    suspend fun saveBus(bus: BusEntity): Long {
        return if (bus.id == 0L) {
            busDao.insertBus(bus)
        } else {
            busDao.updateBus(bus)
            bus.id
        }
    }

    suspend fun deleteBus(id: Long) = busDao.deleteBusById(id)

    // ==========================================
    // MECHANIC OPERATIONS
    // ==========================================
    fun getAllMechanics(): Flow<List<MechanicEntity>> = mechanicDao.getAllMechanics()

    fun getActiveMechanics(): Flow<List<MechanicEntity>> = mechanicDao.getActiveMechanics()

    suspend fun getMechanicById(id: Long): MechanicEntity? = mechanicDao.getMechanicById(id)

    suspend fun saveMechanic(mechanic: MechanicEntity): Long {
        return if (mechanic.id == 0L) {
            mechanicDao.insertMechanic(mechanic)
        } else {
            mechanicDao.updateMechanic(mechanic)
            mechanic.id
        }
    }

    suspend fun deleteMechanic(id: Long) = mechanicDao.deleteMechanicById(id)

    // ==========================================
    // SPAREPART INVENTORY & BARCODE OPERATIONS
    // ==========================================
    fun getAllSpareparts(): Flow<List<SparepartEntity>> = sparepartDao.getAllSpareparts()

    fun searchSpareparts(query: String): Flow<List<SparepartEntity>> {
        return if (query.isBlank()) sparepartDao.getAllSpareparts() else sparepartDao.searchSpareparts(query)
    }

    fun getSparepartsByCategory(category: String): Flow<List<SparepartEntity>> {
        return if (category == "Semua") sparepartDao.getAllSpareparts() else sparepartDao.getSparepartsByCategory(category)
    }

    fun getLowStockSpareparts(): Flow<List<SparepartEntity>> = sparepartDao.getLowStockSpareparts()

    suspend fun getSparepartById(id: Long): SparepartEntity? = sparepartDao.getSparepartById(id)

    suspend fun getSparepartByCode(code: String): SparepartEntity? = sparepartDao.getSparepartByCode(code)

    suspend fun saveSparepart(sparepart: SparepartEntity): Long {
        return if (sparepart.id == 0L) {
            sparepartDao.insertSparepart(sparepart)
        } else {
            sparepartDao.updateSparepart(sparepart)
            sparepart.id
        }
    }

    suspend fun adjustStock(id: Long, delta: Int) {
        if (delta >= 0) {
            sparepartDao.increaseStock(id, delta)
        } else {
            sparepartDao.decreaseStock(id, -delta)
        }
    }

    suspend fun setStock(id: Long, newStock: Int) {
        sparepartDao.setStock(id, newStock)
    }

    suspend fun deleteSparepart(id: Long) = sparepartDao.deleteSparepartById(id)

    // ==========================================
    // SERVICE ORDER OPERATIONS
    // ==========================================
    fun getAllServiceOrders(): Flow<List<ServiceOrderEntity>> = serviceOrderDao.getAllServiceOrders()

    fun getActiveServiceOrders(): Flow<List<ServiceOrderEntity>> = serviceOrderDao.getActiveServiceOrders()

    fun getServiceOrdersByBus(busId: Long): Flow<List<ServiceOrderEntity>> = serviceOrderDao.getServiceOrdersByBusId(busId)

    suspend fun getServiceOrderById(id: Long): ServiceOrderEntity? = serviceOrderDao.getServiceOrderById(id)

    suspend fun saveServiceOrder(order: ServiceOrderEntity): Long {
        val orderId = if (order.id == 0L) {
            serviceOrderDao.insertServiceOrder(order)
        } else {
            serviceOrderDao.updateServiceOrder(order)
            order.id
        }
        // Update bus odometer & status
        val bus = busDao.getBusById(order.busId)
        if (bus != null) {
            val newStatus = if (order.status == "Selesai") "Siap Jalan" else "Dalam Perbaikan"
            val newOdo = maxOf(bus.lastOdometer, order.entryOdometer)
            busDao.updateBusStatusAndOdometer(bus.id, newStatus, newOdo)
        }
        return orderId
    }

    suspend fun completeServiceOrder(orderId: Long, repairNotes: String) {
        val order = serviceOrderDao.getServiceOrderById(orderId) ?: return
        serviceOrderDao.completeServiceOrder(
            id = orderId,
            status = "Selesai",
            exitDate = System.currentTimeMillis(),
            notes = repairNotes
        )
        // Mark bus as "Siap Jalan"
        val bus = busDao.getBusById(order.busId)
        if (bus != null) {
            busDao.updateBusStatusAndOdometer(bus.id, "Siap Jalan", bus.lastOdometer)
        }
    }

    suspend fun deleteServiceOrder(id: Long) = serviceOrderDao.deleteServiceOrderById(id)

    // ==========================================
    // PART USAGE OPERATIONS (WITH AUTO STOCK DEDUCTION)
    // ==========================================
    fun getUsageDetailsByServiceOrder(orderId: Long): Flow<List<PartUsageDetail>> =
        partUsageDao.getUsageDetailsByServiceOrder(orderId)

    fun getUsageDetailsByBus(busId: Long): Flow<List<PartUsageDetail>> =
        partUsageDao.getUsageDetailsByBus(busId)

    /**
     * Catat pemakaian part:
     * 1. Mengurangi stok sparepart di gudang secara otomatis
     * 2. Menghitung subtotal
     * 3. Menyimpan PartUsageEntity
     * 4. Memperbarui totalPartCost pada ServiceOrder terkait
     */
    suspend fun recordPartUsage(
        serviceOrderId: Long,
        sparepartId: Long,
        busId: Long,
        quantity: Int,
        notes: String
    ): Result<Long> {
        val sparepart = sparepartDao.getSparepartById(sparepartId)
            ?: return Result.failure(Exception("Sparepart tidak ditemukan"))

        if (sparepart.stock < quantity) {
            return Result.failure(Exception("Stok tidak mencukupi! Tersisa: ${sparepart.stock} ${sparepart.unit}"))
        }

        val unitPrice = sparepart.unitPrice
        val subtotal = unitPrice * quantity

        val usage = PartUsageEntity(
            serviceOrderId = serviceOrderId,
            sparepartId = sparepartId,
            busId = busId,
            quantity = quantity,
            unitPrice = unitPrice,
            subtotal = subtotal,
            dateUsed = System.currentTimeMillis(),
            notes = notes
        )

        val usageId = database.withTransaction {
            // Kurangi stok part
            sparepartDao.decreaseStock(sparepartId, quantity)
            // Simpan catatan pemakaian
            val id = partUsageDao.insertUsage(usage)
            // Hitung ulang total biaya part pada SPK
            val totalCost = partUsageDao.getTotalPartCostForServiceOrder(serviceOrderId) ?: 0.0
            serviceOrderDao.updateTotalPartCost(serviceOrderId, totalCost)
            id
        }

        return Result.success(usageId)
    }

    /**
     * Hapus pemakaian part:
     * Mengembalikan jumlah stok part yang sebelumnya terpakai, lalu mengupdate total biaya SPK.
     */
    suspend fun removePartUsage(usageId: Long) {
        val usage = partUsageDao.getUsageById(usageId) ?: return

        database.withTransaction {
            // Kembalikan stok part
            sparepartDao.increaseStock(usage.sparepartId, usage.quantity)
            // Hapus record pemakaian
            partUsageDao.deleteUsageById(usageId)
            // Update total biaya SPK
            val totalCost = partUsageDao.getTotalPartCostForServiceOrder(usage.serviceOrderId) ?: 0.0
            serviceOrderDao.updateTotalPartCost(usage.serviceOrderId, totalCost)
        }
    }

    // ==========================================
    // REKAP & LAPORAN DATA
    // ==========================================
    fun getPartUsageSummaries(startDate: Long, endDate: Long): Flow<List<PartUsageSummary>> =
        partUsageDao.getPartUsageSummaries(startDate, endDate)

    fun getTotalPartExpenses(startDate: Long, endDate: Long): Flow<Double?> =
        partUsageDao.getTotalPartExpenses(startDate, endDate)

    fun getWorkshopStats(): Flow<WorkshopStats> {
        val now = System.currentTimeMillis()
        val oneMonthAgo = now - (30L * 24 * 60 * 60 * 1000)

        return combine(
            busDao.getAllBuses(),
            serviceOrderDao.getAllServiceOrders(),
            sparepartDao.getLowStockCount(),
            sparepartDao.getTotalPartCount(),
            partUsageDao.getTotalPartExpenses(oneMonthAgo, now)
        ) { buses, orders, lowStock, totalParts, monthExpenses ->
            val activeBuses = buses.count { it.serviceStatus == "Siap Jalan" }
            val inWorkshop = buses.count { it.serviceStatus == "Dalam Perbaikan" || it.serviceStatus == "Perbaikan Berat" }
            val activeOrders = orders.count { it.status != "Selesai" && it.status != "Batal" }
            val completedOrders = orders.count { it.status == "Selesai" }

            WorkshopStats(
                totalBuses = buses.size,
                activeBuses = activeBuses,
                inWorkshopBuses = inWorkshop,
                activeServiceOrders = activeOrders,
                completedServiceOrders = completedOrders,
                lowStockPartsCount = lowStock,
                totalPartInventoryCount = totalParts,
                totalExpensesThisMonth = monthExpenses ?: 0.0
            )
        }
    }

    // ==========================================
    // BACKUP & RESTORE DATA (100% OFFLINE LOCAL JSON)
    // ==========================================
    suspend fun exportToJson(): String {
        val buses = busDao.getAllBuses().first()
        val mechanics = mechanicDao.getAllMechanics().first()
        val spareparts = sparepartDao.getAllSpareparts().first()
        val orders = serviceOrderDao.getAllServiceOrders().first()
        val usages = partUsageDao.getAllUsages().first()

        val root = JSONObject()
        root.put("app", "BengkelBus App")
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())

        val busesArray = JSONArray()
        buses.forEach {
            busesArray.put(JSONObject().apply {
                put("id", it.id)
                put("plateNumber", it.plateNumber)
                put("model", it.model)
                put("year", it.year)
                put("lastOdometer", it.lastOdometer)
                put("serviceStatus", it.serviceStatus)
                put("operatorName", it.operatorName)
                put("notes", it.notes)
                put("updatedAt", it.updatedAt)
            })
        }
        root.put("buses", busesArray)

        val mechanicsArray = JSONArray()
        mechanics.forEach {
            mechanicsArray.put(JSONObject().apply {
                put("id", it.id)
                put("name", it.name)
                put("specialization", it.specialization)
                put("phone", it.phone)
                put("status", it.status)
                put("joinedYear", it.joinedYear)
            })
        }
        root.put("mechanics", mechanicsArray)

        val partsArray = JSONArray()
        spareparts.forEach {
            partsArray.put(JSONObject().apply {
                put("id", it.id)
                put("partCode", it.partCode)
                put("name", it.name)
                put("category", it.category)
                put("stock", it.stock)
                put("minStock", it.minStock)
                put("unit", it.unit)
                put("unitPrice", it.unitPrice)
                put("shelfLocation", it.shelfLocation)
                put("updatedAt", it.updatedAt)
            })
        }
        root.put("spareparts", partsArray)

        val ordersArray = JSONArray()
        orders.forEach {
            ordersArray.put(JSONObject().apply {
                put("id", it.id)
                put("spkNumber", it.spkNumber)
                put("busId", it.busId)
                if (it.mechanicId != null) put("mechanicId", it.mechanicId)
                put("serviceType", it.serviceType)
                put("entryOdometer", it.entryOdometer)
                put("entryDate", it.entryDate)
                if (it.exitDate != null) put("exitDate", it.exitDate)
                put("status", it.status)
                put("complaints", it.complaints)
                put("repairNotes", it.repairNotes)
                put("laborCost", it.laborCost)
                put("totalPartCost", it.totalPartCost)
                put("updatedAt", it.updatedAt)
            })
        }
        root.put("serviceOrders", ordersArray)

        val usagesArray = JSONArray()
        usages.forEach {
            usagesArray.put(JSONObject().apply {
                put("id", it.id)
                put("serviceOrderId", it.serviceOrderId)
                put("sparepartId", it.sparepartId)
                put("busId", it.busId)
                put("quantity", it.quantity)
                put("unitPrice", it.unitPrice)
                put("subtotal", it.subtotal)
                put("dateUsed", it.dateUsed)
                put("notes", it.notes)
            })
        }
        root.put("partUsages", usagesArray)

        return root.toString(2)
    }

    suspend fun importFromJson(jsonString: String, replaceAll: Boolean = true): Result<String> {
        return try {
            val root = JSONObject(jsonString)
            val busesArray = root.optJSONArray("buses") ?: JSONArray()
            val mechanicsArray = root.optJSONArray("mechanics") ?: JSONArray()
            val partsArray = root.optJSONArray("spareparts") ?: JSONArray()
            val ordersArray = root.optJSONArray("serviceOrders") ?: JSONArray()
            val usagesArray = root.optJSONArray("partUsages") ?: JSONArray()

            val buses = mutableListOf<BusEntity>()
            for (i in 0 until busesArray.length()) {
                val obj = busesArray.getJSONObject(i)
                buses.add(
                    BusEntity(
                        id = if (replaceAll) obj.optLong("id", 0) else 0,
                        plateNumber = obj.optString("plateNumber", ""),
                        model = obj.optString("model", ""),
                        year = obj.optInt("year", 2020),
                        lastOdometer = obj.optInt("lastOdometer", 0),
                        serviceStatus = obj.optString("serviceStatus", "Siap Jalan"),
                        operatorName = obj.optString("operatorName", "PO Primadona Trans"),
                        notes = obj.optString("notes", ""),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
            }

            val mechanics = mutableListOf<MechanicEntity>()
            for (i in 0 until mechanicsArray.length()) {
                val obj = mechanicsArray.getJSONObject(i)
                mechanics.add(
                    MechanicEntity(
                        id = if (replaceAll) obj.optLong("id", 0) else 0,
                        name = obj.optString("name", ""),
                        specialization = obj.optString("specialization", ""),
                        phone = obj.optString("phone", ""),
                        status = obj.optString("status", "Aktif"),
                        joinedYear = obj.optInt("joinedYear", 2020)
                    )
                )
            }

            val parts = mutableListOf<SparepartEntity>()
            for (i in 0 until partsArray.length()) {
                val obj = partsArray.getJSONObject(i)
                parts.add(
                    SparepartEntity(
                        id = if (replaceAll) obj.optLong("id", 0) else 0,
                        partCode = obj.optString("partCode", "PART-$i"),
                        name = obj.optString("name", ""),
                        category = obj.optString("category", "Lainnya"),
                        stock = obj.optInt("stock", 0),
                        minStock = obj.optInt("minStock", 2),
                        unit = obj.optString("unit", "Pcs"),
                        unitPrice = obj.optDouble("unitPrice", 0.0),
                        shelfLocation = obj.optString("shelfLocation", "Rak Utama"),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
            }

            val orders = mutableListOf<ServiceOrderEntity>()
            for (i in 0 until ordersArray.length()) {
                val obj = ordersArray.getJSONObject(i)
                orders.add(
                    ServiceOrderEntity(
                        id = if (replaceAll) obj.optLong("id", 0) else 0,
                        spkNumber = obj.optString("spkNumber", "SPK-$i"),
                        busId = obj.optLong("busId", 1),
                        mechanicId = if (obj.has("mechanicId")) obj.optLong("mechanicId") else null,
                        serviceType = obj.optString("serviceType", "Servis Berkala"),
                        entryOdometer = obj.optInt("entryOdometer", 0),
                        entryDate = obj.optLong("entryDate", System.currentTimeMillis()),
                        exitDate = if (obj.has("exitDate")) obj.optLong("exitDate") else null,
                        status = obj.optString("status", "Dikerjakan"),
                        complaints = obj.optString("complaints", ""),
                        repairNotes = obj.optString("repairNotes", ""),
                        laborCost = obj.optDouble("laborCost", 0.0),
                        totalPartCost = obj.optDouble("totalPartCost", 0.0),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
            }

            val usages = mutableListOf<PartUsageEntity>()
            for (i in 0 until usagesArray.length()) {
                val obj = usagesArray.getJSONObject(i)
                usages.add(
                    PartUsageEntity(
                        id = if (replaceAll) obj.optLong("id", 0) else 0,
                        serviceOrderId = obj.optLong("serviceOrderId", 1),
                        sparepartId = obj.optLong("sparepartId", 1),
                        busId = obj.optLong("busId", 1),
                        quantity = obj.optInt("quantity", 1),
                        unitPrice = obj.optDouble("unitPrice", 0.0),
                        subtotal = obj.optDouble("subtotal", 0.0),
                        dateUsed = obj.optLong("dateUsed", System.currentTimeMillis()),
                        notes = obj.optString("notes", "")
                    )
                )
            }

            database.withTransaction {
                if (replaceAll) {
                    partUsageDao.deleteAll()
                    serviceOrderDao.deleteAll()
                    sparepartDao.deleteAll()
                    mechanicDao.deleteAll()
                    busDao.deleteAll()
                }

                busDao.insertAll(buses)
                mechanicDao.insertAll(mechanics)
                sparepartDao.insertAll(parts)
                serviceOrderDao.insertAll(orders)
                partUsageDao.insertAll(usages)
            }

            Result.success("Berhasil memulihkan ${buses.size} Bus, ${mechanics.size} Mekanik, ${parts.size} Sparepart, ${orders.size} SPK, dan ${usages.size} Pemakaian Part.")
        } catch (e: Exception) {
            Result.failure(Exception("Gagal memulihkan file: ${e.localizedMessage}"))
        }
    }

    // ==========================================
    // INITIAL SEED DATA (BENGKEL BUS REALISTIS)
    // ==========================================
    suspend fun seedInitialDataIfEmpty() {
        val existingBuses = busDao.getAllBuses().first()
        if (existingBuses.isNotEmpty()) return

        val now = System.currentTimeMillis()
        val oneDay = 24 * 60 * 60 * 1000L

        val initialBuses = listOf(
            BusEntity(
                id = 1,
                plateNumber = "B 7123 VGA",
                model = "Mercedes-Benz OH 1626 / Jetbus 3+ HDD",
                year = 2021,
                lastOdometer = 148500,
                serviceStatus = "Dalam Perbaikan",
                operatorName = "PO Primadona Trans",
                notes = "Jalur Patas Jakarta - Solo. Ada bunyi mendecit di pengereman depan."
            ),
            BusEntity(
                id = 2,
                plateNumber = "B 7540 KGA",
                model = "Hino RK8 R260 / Legacy SR2 HD Prime",
                year = 2020,
                lastOdometer = 210400,
                serviceStatus = "Siap Jalan",
                operatorName = "PO Primadona Trans",
                notes = "Kondisi prima, baru selesai servis berkala 200rb km."
            ),
            BusEntity(
                id = 3,
                plateNumber = "B 7899 TGA",
                model = "Scania K360IB Opticruise / Avante H8",
                year = 2022,
                lastOdometer = 112000,
                serviceStatus = "Perlu Servis",
                operatorName = "PO Primadona Trans",
                notes = "Oli transmisi & filter Donaldson mendekati jadwal pergantian."
            ),
            BusEntity(
                id = 4,
                plateNumber = "AD 1450 CF",
                model = "Mercedes-Benz OF 1623 Front Engine / Nucleus",
                year = 2019,
                lastOdometer = 295000,
                serviceStatus = "Siap Jalan",
                operatorName = "PO Primadona Trans",
                notes = "Armada pariwisata cadangan, AC Denso dingin normal."
            ),
            BusEntity(
                id = 5,
                plateNumber = "B 7001 XGA",
                model = "Volvo B11R 430HP 6x2 / Jetbus 3+ UHD Tronton",
                year = 2023,
                lastOdometer = 68000,
                serviceStatus = "Siap Jalan",
                operatorName = "PO Primadona Trans",
                notes = "Armada Super Executive Jakarta - Surabaya. Suspensi udara lembut."
            )
        )

        val initialMechanics = listOf(
            MechanicEntity(
                id = 1,
                name = "Bambang Sudiro",
                specialization = "Mesin OM906LA & Transmisi",
                phone = "0812-3456-7890",
                status = "Aktif",
                joinedYear = 2018
            ),
            MechanicEntity(
                id = 2,
                name = "Joko Santoso",
                specialization = "Sistem Rem Tromol & Air Suspension",
                phone = "0813-9876-5432",
                status = "Aktif",
                joinedYear = 2019
            ),
            MechanicEntity(
                id = 3,
                name = "Hendra Wijaya",
                specialization = "Kelistrikan Bus & AC Denso LD8",
                phone = "0857-1122-3344",
                status = "Aktif",
                joinedYear = 2021
            ),
            MechanicEntity(
                id = 4,
                name = "Dani Prasetyo",
                specialization = "Chasis, Roda & Kaki-kaki",
                phone = "0821-4455-6677",
                status = "Aktif",
                joinedYear = 2022
            )
        )

        val initialSpareparts = listOf(
            SparepartEntity(
                id = 1,
                partCode = "BRK-PAD-1626",
                name = "Kampas Rem Depan Heavy Duty OH1626",
                category = "Pengereman",
                stock = 8,
                minStock = 3,
                unit = "Set",
                unitPrice = 850000.0,
                shelfLocation = "Rak A-01"
            ),
            SparepartEntity(
                id = 2,
                partCode = "FLT-OIL-MB01",
                name = "Filter Oli Mesin OM906LA / MB",
                category = "Filter",
                stock = 14,
                minStock = 4,
                unit = "Pcs",
                unitPrice = 175000.0,
                shelfLocation = "Rak B-02"
            ),
            SparepartEntity(
                id = 3,
                partCode = "OIL-15W40-DRM",
                name = "Oli Mesin Diesel Meditran SX 15W-40",
                category = "Mesin & Pelumas",
                stock = 85,
                minStock = 30,
                unit = "Liter",
                unitPrice = 58000.0,
                shelfLocation = "Gudang Oli B-1"
            ),
            SparepartEntity(
                id = 4,
                partCode = "AIR-SUSP-BLN",
                name = "Balon Suspensi Udara Belakang Rolling Lobe",
                category = "Suspensi & Balon",
                stock = 4,
                minStock = 2,
                unit = "Pcs",
                unitPrice = 1450000.0,
                shelfLocation = "Rak C-05"
            ),
            SparepartEntity(
                id = 5,
                partCode = "VBLT-ALT-HINO",
                name = "Fan Belt Alternator & Water Pump Hino RK8",
                category = "Mesin & Pelumas",
                stock = 6,
                minStock = 2,
                unit = "Pcs",
                unitPrice = 220000.0,
                shelfLocation = "Rak B-04"
            ),
            SparepartEntity(
                id = 6,
                partCode = "FLT-AIR-DONALD",
                name = "Filter Udara Donaldson Primary E100",
                category = "Filter",
                stock = 1, // ALERT STOK MENIPIS!
                minStock = 3,
                unit = "Pcs",
                unitPrice = 620000.0,
                shelfLocation = "Rak B-06"
            ),
            SparepartEntity(
                id = 7,
                partCode = "RELAY-24V-BOSCH",
                name = "Relay 24V 40A 5-Pin Bosch Heavy Duty",
                category = "Kelistrikan",
                stock = 24,
                minStock = 5,
                unit = "Pcs",
                unitPrice = 45000.0,
                shelfLocation = "Bin E-01"
            ),
            SparepartEntity(
                id = 8,
                partCode = "KPS-KOPLING-MB",
                name = "Clutch Disc / Plat Kopling 430mm OH1626",
                category = "Transmisi",
                stock = 2,
                minStock = 2,
                unit = "Set",
                unitPrice = 2850000.0,
                shelfLocation = "Rak D-02"
            )
        )

        val initialOrders = listOf(
            ServiceOrderEntity(
                id = 1,
                spkNumber = "SPK-2026-001",
                busId = 1, // B 7123 VGA
                mechanicId = 2, // Joko Santoso
                serviceType = "Perbaikan Rem & Kaki-kaki",
                entryOdometer = 148500,
                entryDate = now - (2 * oneDay),
                exitDate = null,
                status = "Dikerjakan",
                complaints = "Rem depan kiri mendecit keras saat pengereman menurun dan bergetar.",
                repairNotes = "Bongkar tromol, ganti kampas rem set depan dan setel ulang celah chamber.",
                laborCost = 250000.0,
                totalPartCost = 850000.0
            ),
            ServiceOrderEntity(
                id = 2,
                spkNumber = "SPK-2026-002",
                busId = 2, // B 7540 KGA
                mechanicId = 1, // Bambang Sudiro
                serviceType = "Servis Rutin / Berkala",
                entryOdometer = 210400,
                entryDate = now - (5 * oneDay),
                exitDate = now - (4 * oneDay),
                status = "Selesai",
                complaints = "Jadwal ganti oli mesin 20.000 km dan pengecekan filter udara.",
                repairNotes = "Ganti oli mesin 28 Liter dan filter oli. Kondisi bus siap jalan.",
                laborCost = 200000.0,
                totalPartCost = 1799000.0
            )
        )

        val initialUsages = listOf(
            PartUsageEntity(
                id = 1,
                serviceOrderId = 1,
                sparepartId = 1, // BRK-PAD-1626
                busId = 1,
                quantity = 1,
                unitPrice = 850000.0,
                subtotal = 850000.0,
                dateUsed = now - (2 * oneDay),
                notes = "Penggantian kampas rem depan set kanan-kiri"
            ),
            PartUsageEntity(
                id = 2,
                serviceOrderId = 2,
                sparepartId = 2, // FLT-OIL-MB01
                busId = 2,
                quantity = 1,
                unitPrice = 175000.0,
                subtotal = 175000.0,
                dateUsed = now - (5 * oneDay),
                notes = "Filter oli mesin"
            ),
            PartUsageEntity(
                id = 3,
                serviceOrderId = 2,
                sparepartId = 3, // OIL-15W40-DRM
                busId = 2,
                quantity = 28,
                unitPrice = 58000.0,
                subtotal = 1624000.0,
                dateUsed = now - (5 * oneDay),
                notes = "Penggantian oli mesin 28 Liter"
            )
        )

        database.withTransaction {
            busDao.insertAll(initialBuses)
            mechanicDao.insertAll(initialMechanics)
            sparepartDao.insertAll(initialSpareparts)
            serviceOrderDao.insertAll(initialOrders)
            partUsageDao.insertAll(initialUsages)
        }
    }
}
