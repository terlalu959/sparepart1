package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Entitas Pemakaian Sparepart yang terikat pada unit bus dan pekerjaan/SPK tertentu.
 */
@Entity(
    tableName = "part_usages",
    foreignKeys = [
        ForeignKey(
            entity = ServiceOrderEntity::class,
            parentColumns = ["id"],
            childColumns = ["serviceOrderId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = SparepartEntity::class,
            parentColumns = ["id"],
            childColumns = ["sparepartId"],
            onDelete = ForeignKey.RESTRICT
        ),
        ForeignKey(
            entity = BusEntity::class,
            parentColumns = ["id"],
            childColumns = ["busId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["serviceOrderId"]),
        Index(value = ["sparepartId"]),
        Index(value = ["busId"])
    ]
)
data class PartUsageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val serviceOrderId: Long,
    val sparepartId: Long,
    val busId: Long,
    val quantity: Int,              // Jumlah unit part terpakai
    val unitPrice: Double,          // Harga satuan saat pemakaian
    val subtotal: Double,           // quantity * unitPrice
    val dateUsed: Long = System.currentTimeMillis(),
    val notes: String = ""          // e.g. "Roda kanan belakang", "Penggantian berkala 50rb km"
)
