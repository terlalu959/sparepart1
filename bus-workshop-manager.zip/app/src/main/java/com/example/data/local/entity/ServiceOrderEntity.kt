package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Entitas Surat Perintah Kerja (SPK) / Pencatatan Servis per Bus.
 */
@Entity(
    tableName = "service_orders",
    foreignKeys = [
        ForeignKey(
            entity = BusEntity::class,
            parentColumns = ["id"],
            childColumns = ["busId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = MechanicEntity::class,
            parentColumns = ["id"],
            childColumns = ["mechanicId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [
        Index(value = ["busId"]),
        Index(value = ["mechanicId"]),
        Index(value = ["spkNumber"], unique = true)
    ]
)
data class ServiceOrderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val spkNumber: String,          // e.g. "SPK-2026-001"
    val busId: Long,                // Relasi ke Unit Bus
    val mechanicId: Long? = null,   // Relasi ke Mekanik Penanggung Jawab
    val serviceType: String,        // "Servis Rutin / Berkala", "Perbaikan Rem & Kaki-kaki", "Overhaul Mesin", "Perbaikan AC & Kelistrikan", "Breakdown Jalan"
    val entryOdometer: Int,         // Kilometer saat masuk bengkel
    val entryDate: Long,            // Waktu masuk bengkel (timestamp ms)
    val exitDate: Long? = null,     // Waktu selesai/keluar bengkel (timestamp ms)
    val status: String,             // "Dikerjakan", "Menunggu Part", "Selesai", "Batal"
    val complaints: String = "",    // Keluhan pengemudi / temuan inspeksi
    val repairNotes: String = "",   // Catatan penanganan teknisi
    val laborCost: Double = 0.0,    // Biaya jasa / ongkos kerja (Rp)
    val totalPartCost: Double = 0.0,// Total biaya part yang digunakan (Rp, terhitung dari part usage)
    val updatedAt: Long = System.currentTimeMillis()
)
