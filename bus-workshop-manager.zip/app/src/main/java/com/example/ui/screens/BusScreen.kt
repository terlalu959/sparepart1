package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.BusEntity
import com.example.ui.components.BusStatusBadge
import com.example.ui.viewmodel.WorkshopViewModel
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BusScreen(
    viewModel: WorkshopViewModel,
    onViewBusHistory: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val buses by viewModel.buses.collectAsStateWithLifecycle()
    val searchQuery by viewModel.busSearchQuery.collectAsStateWithLifecycle()
    val statusFilter by viewModel.busStatusFilter.collectAsStateWithLifecycle()

    var showAddEditDialog by remember { mutableStateOf(false) }
    var busToEdit by remember { mutableStateOf<BusEntity?>(null) }
    var busToDelete by remember { mutableStateOf<BusEntity?>(null) }
    var busDetailToShow by remember { mutableStateOf<BusEntity?>(null) }

    val statusOptions = listOf("Semua", "Siap Jalan", "Dalam Perbaikan", "Perlu Servis", "Perbaikan Berat")

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B1120))
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header & Total Count
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Manajemen Armada Bus",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${buses.size} unit bus terdaftar di bengkel",
                            color = Color(0xFF94A3B8),
                            fontSize = 13.sp
                        )
                    }

                    Button(
                        onClick = {
                            busToEdit = null
                            showAddEditDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("add_bus_top_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF0F172A))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Tambah", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setBusSearchQuery(it) },
                    placeholder = { Text("Cari Nopol (contoh: B 7123 VGA) atau Model...") },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF94A3B8))
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("bus_search_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF1E293B),
                        unfocusedContainerColor = Color(0xFF1E293B),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFFF59E0B),
                        unfocusedBorderColor = Color(0xFF334155)
                    ),
                    singleLine = true
                )
            }

            // Status Filter Chips
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(statusOptions) { status ->
                        val isSelected = statusFilter == status
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setBusStatusFilter(status) },
                            label = { Text(status, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFFF59E0B),
                                selectedLabelColor = Color(0xFF0F172A),
                                containerColor = Color(0xFF1E293B),
                                labelColor = Color(0xFFCBD5E1)
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) Color(0xFFF59E0B) else Color(0xFF334155)
                            )
                        )
                    }
                }
            }

            // Bus List
            if (buses.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.DirectionsBus,
                                contentDescription = null,
                                tint = Color(0xFF64748B),
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Tidak ada armada bus ditemukan",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "Coba ubah kata kunci pencarian atau tambahkan unit baru.",
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            } else {
                items(buses, key = { it.id }) { bus ->
                    BusItemCard(
                        bus = bus,
                        onClick = { busDetailToShow = bus },
                        onEdit = {
                            busToEdit = bus
                            showAddEditDialog = true
                        },
                        onDelete = { busToDelete = bus },
                        onViewHistory = { onViewBusHistory(bus.id) }
                    )
                }
            }
        }
    }

    // Add / Edit Bus Dialog
    if (showAddEditDialog) {
        AddEditBusDialog(
            bus = busToEdit,
            onDismiss = { showAddEditDialog = false },
            onSave = { bus ->
                viewModel.saveBus(bus)
                showAddEditDialog = false
            }
        )
    }

    // Delete Confirmation Dialog
    if (busToDelete != null) {
        val target = busToDelete!!
        AlertDialog(
            onDismissRequest = { busToDelete = null },
            title = { Text("Hapus Unit Bus?") },
            text = { Text("Apakah Anda yakin ingin menghapus bus ${target.plateNumber} (${target.model})? Semua riwayat servis terkait akan ikut terhapus.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteBus(target.id)
                        busToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                    modifier = Modifier.testTag("confirm_delete_bus_button")
                ) {
                    Text("Hapus Unit", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { busToDelete = null }) {
                    Text("Batal")
                }
            },
            containerColor = Color(0xFF1E293B),
            titleContentColor = Color.White,
            textContentColor = Color(0xFFCBD5E1)
        )
    }

    // Detail Bus Dialog
    if (busDetailToShow != null) {
        val bus = busDetailToShow!!
        AlertDialog(
            onDismissRequest = { busDetailToShow = null },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(bus.plateNumber, fontWeight = FontWeight.Bold, color = Color(0xFFF59E0B))
                    BusStatusBadge(status = bus.serviceStatus)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DetailRow("Model & Karoseri", bus.model)
                    DetailRow("Tahun Pembuatan", "${bus.year}")
                    DetailRow("Odometer Terakhir", "${NumberFormat.getNumberInstance(Locale("id", "ID")).format(bus.lastOdometer)} km")
                    DetailRow("Operator / PO", bus.operatorName)
                    if (bus.notes.isNotBlank()) {
                        DetailRow("Catatan Khusus", bus.notes)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val id = bus.id
                        busDetailToShow = null
                        onViewBusHistory(id)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B))
                ) {
                    Icon(Icons.Default.History, contentDescription = null, tint = Color(0xFF0F172A))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Riwayat Servis Bus", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { busDetailToShow = null }) {
                    Text("Tutup")
                }
            },
            containerColor = Color(0xFF1E293B),
            titleContentColor = Color.White,
            textContentColor = Color(0xFFCBD5E1)
        )
    }
}

@Composable
fun BusItemCard(
    bus: BusEntity,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onViewHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(14.dp))
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(Color(0xFF0F172A), RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.DirectionsBus,
                            contentDescription = null,
                            tint = Color(0xFFF59E0B),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = bus.plateNumber,
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = bus.operatorName,
                            color = Color(0xFF94A3B8),
                            fontSize = 12.sp
                        )
                    }
                }

                BusStatusBadge(status = bus.serviceStatus)
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = bus.model,
                color = Color(0xFFE2E8F0),
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = null,
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${NumberFormat.getNumberInstance(Locale("id", "ID")).format(bus.lastOdometer)} km",
                        color = Color(0xFF38BDF8),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = " • Thn ${bus.year}",
                        color = Color(0xFF94A3B8),
                        fontSize = 13.sp
                    )
                }

                // Action Buttons
                Row {
                    IconButton(
                        onClick = onViewHistory,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.History, contentDescription = "Riwayat Servis", tint = Color(0xFF38BDF8))
                    }
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("edit_bus_${bus.id}")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Bus", tint = Color(0xFFF59E0B))
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("delete_bus_${bus.id}")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Hapus Bus", tint = Color(0xFFEF4444))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditBusDialog(
    bus: BusEntity?,
    onDismiss: () -> Unit,
    onSave: (BusEntity) -> Unit
) {
    val isEdit = bus != null

    var plateNumber by remember { mutableStateOf(bus?.plateNumber ?: "") }
    var model by remember { mutableStateOf(bus?.model ?: "") }
    var yearStr by remember { mutableStateOf(bus?.year?.toString() ?: "2021") }
    var odometerStr by remember { mutableStateOf(bus?.lastOdometer?.toString() ?: "100000") }
    var operatorName by remember { mutableStateOf(bus?.operatorName ?: "PO Primadona Trans") }
    var notes by remember { mutableStateOf(bus?.notes ?: "") }
    var serviceStatus by remember { mutableStateOf(bus?.serviceStatus ?: "Siap Jalan") }

    val statusOptions = listOf("Siap Jalan", "Dalam Perbaikan", "Perlu Servis", "Perbaikan Berat")
    var statusExpanded by remember { mutableStateOf(false) }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isEdit) "Edit Data Unit Bus" else "Tambah Unit Bus Baru",
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (errorMessage != null) {
                    Text(text = errorMessage!!, color = Color(0xFFEF4444), fontSize = 12.sp)
                }

                OutlinedTextField(
                    value = plateNumber,
                    onValueChange = { plateNumber = it.uppercase() },
                    label = { Text("Nomor Polisi (Nopol)") },
                    placeholder = { Text("Contoh: B 7123 VGA") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("bus_plate_input"),
                    colors = dialogTextFieldColors()
                )

                OutlinedTextField(
                    value = model,
                    onValueChange = { model = it },
                    label = { Text("Model & Karoseri") },
                    placeholder = { Text("Contoh: Mercedes-Benz OH 1626 / Jetbus 3+") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("bus_model_input"),
                    colors = dialogTextFieldColors()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = yearStr,
                        onValueChange = { yearStr = it },
                        label = { Text("Tahun") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = dialogTextFieldColors()
                    )
                    OutlinedTextField(
                        value = odometerStr,
                        onValueChange = { odometerStr = it },
                        label = { Text("Odometer (km)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = dialogTextFieldColors()
                    )
                }

                // Dropdown Status Servis
                ExposedDropdownMenuBox(
                    expanded = statusExpanded,
                    onExpandedChange = { statusExpanded = !statusExpanded }
                ) {
                    OutlinedTextField(
                        value = serviceStatus,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Status Servis") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        colors = dialogTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = statusExpanded,
                        onDismissRequest = { statusExpanded = false },
                        modifier = Modifier.background(Color(0xFF1E293B))
                    ) {
                        statusOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option, color = Color.White) },
                                onClick = {
                                    serviceStatus = option
                                    statusExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = operatorName,
                    onValueChange = { operatorName = it },
                    label = { Text("Operator / PO Armada") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = dialogTextFieldColors()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Catatan Tambahan (Opsional)") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2,
                    colors = dialogTextFieldColors()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (plateNumber.isBlank()) {
                        errorMessage = "Nomor Polisi tidak boleh kosong"
                        return@Button
                    }
                    if (model.isBlank()) {
                        errorMessage = "Model bus tidak boleh kosong"
                        return@Button
                    }
                    val year = yearStr.toIntOrNull() ?: 2020
                    val odo = odometerStr.toIntOrNull() ?: 0

                    onSave(
                        BusEntity(
                            id = bus?.id ?: 0L,
                            plateNumber = plateNumber.trim(),
                            model = model.trim(),
                            year = year,
                            lastOdometer = odo,
                            serviceStatus = serviceStatus,
                            operatorName = operatorName.trim(),
                            notes = notes.trim(),
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                modifier = Modifier.testTag("save_bus_button")
            ) {
                Text("Simpan Data", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        },
        containerColor = Color(0xFF1E293B),
        titleContentColor = Color.White,
        textContentColor = Color(0xFFCBD5E1)
    )
}

@Composable
fun dialogTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedBorderColor = Color(0xFFF59E0B),
    unfocusedBorderColor = Color(0xFF475569),
    focusedLabelColor = Color(0xFFF59E0B),
    unfocusedLabelColor = Color(0xFF94A3B8),
    cursorColor = Color(0xFFF59E0B)
)

@Composable
fun DetailRow(label: String, value: String) {
    Column {
        Text(text = label, color = Color(0xFF94A3B8), fontSize = 12.sp)
        Text(text = value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}
