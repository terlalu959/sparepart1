package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.BusEntity
import com.example.data.local.entity.MechanicEntity
import com.example.ui.components.SpkStatusBadge
import com.example.ui.components.formatDate
import com.example.ui.components.formatDateShort
import com.example.ui.components.formatRupiah
import com.example.ui.viewmodel.WorkshopViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsAndMechanicsScreen(
    viewModel: WorkshopViewModel,
    preselectedBusIdForHistory: Long? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedSubTab by remember { mutableIntStateOf(if (preselectedBusIdForHistory != null) 0 else 0) } // 0: Rekap & Riwayat Bus, 1: Mekanik, 2: Backup/Restore

    val mechanics by viewModel.mechanics.collectAsStateWithLifecycle()
    val buses by viewModel.buses.collectAsStateWithLifecycle()
    val partSummaries by viewModel.reportPartSummaries.collectAsStateWithLifecycle()
    val totalExpense by viewModel.reportTotalExpense.collectAsStateWithLifecycle()
    val selectedDays by viewModel.reportDateRangeDays.collectAsStateWithLifecycle()

    val selectedBusId by viewModel.selectedBusForHistory.collectAsStateWithLifecycle()
    val busHistoryOrders by viewModel.busHistoryOrders.collectAsStateWithLifecycle()
    val busHistoryParts by viewModel.busHistoryPartsUsed.collectAsStateWithLifecycle()

    // Preselect bus if passed
    if (preselectedBusIdForHistory != null && selectedBusId == null) {
        viewModel.selectBusForHistory(preselectedBusIdForHistory)
    }

    var showAddEditMechanicDialog by remember { mutableStateOf(false) }
    var mechanicToEdit by remember { mutableStateOf<MechanicEntity?>(null) }
    var mechanicToDelete by remember { mutableStateOf<MechanicEntity?>(null) }

    // Backup & Restore State
    var showRestoreDialog by remember { mutableStateOf(false) }
    var pasteRestoreText by remember { mutableStateOf("") }
    var pendingExportJson by remember { mutableStateOf<String?>(null) }

    // SAF Document Creator for Local JSON Backup
    val createDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null && pendingExportJson != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { os ->
                    os.write(pendingExportJson!!.toByteArray())
                }
                Toast.makeText(context, "File cadangan berhasil disimpan", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Gagal menyimpan file: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // SAF Document Opener for Restore
    val openDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { isStream ->
                    val json = isStream.bufferedReader().use { it.readText() }
                    pasteRestoreText = json
                    showRestoreDialog = true
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Gagal membaca file: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val dateRangeOptions = listOf(
        7 to "7 Hari",
        30 to "30 Hari",
        90 to "3 Bulan",
        365 to "1 Tahun",
        0 to "Semua"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B1120))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Sub-Navigation Tabs
            TabRow(
                selectedTabIndex = selectedSubTab,
                containerColor = Color(0xFF1E293B),
                contentColor = Color(0xFFF59E0B)
            ) {
                Tab(
                    selected = selectedSubTab == 0,
                    onClick = { selectedSubTab = 0 },
                    text = { Text("Rekap & Laporan", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedSubTab == 1,
                    onClick = { selectedSubTab = 1 },
                    text = { Text("Mekanik (${mechanics.size})", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedSubTab == 2,
                    onClick = { selectedSubTab = 2 },
                    text = { Text("Cadangan Data", fontWeight = FontWeight.Bold) }
                )
            }

            when (selectedSubTab) {
                0 -> {
                    // ==========================================
                    // REKAP & LAPORAN DATA
                    // ==========================================
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Date Range Filter & Total Expense
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(14.dp))
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = "REKAP PENGELUARAN SPAREPART",
                                        color = Color(0xFF94A3B8),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = formatRupiah(totalExpense),
                                        color = Color(0xFF10B981),
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))

                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        items(dateRangeOptions) { (days, label) ->
                                            val isSelected = selectedDays == days
                                            FilterChip(
                                                selected = isSelected,
                                                onClick = { viewModel.setReportDateRange(days) },
                                                label = { Text(label, fontSize = 11.sp) },
                                                colors = FilterChipDefaults.filterChipColors(
                                                    selectedContainerColor = Color(0xFFF59E0B),
                                                    selectedLabelColor = Color(0xFF0F172A),
                                                    containerColor = Color(0xFF0F172A),
                                                    labelColor = Color(0xFFCBD5E1)
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Top Consumed Spareparts Breakdown
                        item {
                            Text(
                                text = "RINCIAN PEMAKAIAN PART DALAM PERIODE INI",
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }

                        if (partSummaries.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF1E293B), RoundedCornerShape(12.dp))
                                        .padding(20.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "Tidak ada pemakaian part tercatat dalam periode ini.",
                                        color = Color(0xFF64748B),
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        } else {
                            items(partSummaries) { summary ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = summary.partName,
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                            Text(
                                                text = "${summary.partCode} • ${summary.category}",
                                                color = Color(0xFF94A3B8),
                                                fontSize = 12.sp
                                            )
                                            Text(
                                                text = "Total Pakai: ${summary.totalQuantity} ${summary.unit}",
                                                color = Color(0xFF38BDF8),
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }

                                        Text(
                                            text = formatRupiah(summary.totalCost),
                                            color = Color(0xFF10B981),
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        // Riwayat Servis per Unit Bus Section
                        item {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "RIWAYAT SERVIS PER UNIT BUS",
                                color = Color(0xFFF59E0B),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            // Bus Selector Row
                            var busDropdownExpanded by remember { mutableStateOf(false) }
                            val currentSelectedBus = buses.find { it.id == selectedBusId }

                            ExposedDropdownMenuBox(
                                expanded = busDropdownExpanded,
                                onExpandedChange = { busDropdownExpanded = !busDropdownExpanded }
                            ) {
                                OutlinedTextField(
                                    value = currentSelectedBus?.let { "${it.plateNumber} - ${it.model}" } ?: "Pilih Unit Bus untuk Melihat Riwayat...",
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Pilih Unit Bus") },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = busDropdownExpanded) },
                                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                                    colors = dialogTextFieldColors()
                                )
                                ExposedDropdownMenu(
                                    expanded = busDropdownExpanded,
                                    onDismissRequest = { busDropdownExpanded = false },
                                    modifier = Modifier.background(Color(0xFF1E293B))
                                ) {
                                    buses.forEach { bus ->
                                        DropdownMenuItem(
                                            text = { Text("${bus.plateNumber} (${bus.model})", color = Color.White) },
                                            onClick = {
                                                viewModel.selectBusForHistory(bus.id)
                                                busDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        if (selectedBusId != null) {
                            if (busHistoryOrders.isEmpty()) {
                                item {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFF1E293B), RoundedCornerShape(10.dp))
                                            .padding(16.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("Belum ada riwayat servis untuk bus ini.", color = Color(0xFF94A3B8), fontSize = 13.sp)
                                    }
                                }
                            } else {
                                item {
                                    Text(
                                        text = "Ditemukan ${busHistoryOrders.size} riwayat servis & ${busHistoryParts.size} part terpasang:",
                                        color = Color(0xFFCBD5E1),
                                        fontSize = 12.sp
                                    )
                                }

                                items(busHistoryOrders) { order ->
                                    val orderParts = busHistoryParts.filter { it.serviceOrderId == order.id }
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp))
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(order.spkNumber, color = Color(0xFFF59E0B), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                SpkStatusBadge(status = order.status)
                                            }
                                            Text(order.serviceType, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                            Text("Odometer saat servis: ${order.entryOdometer} km", color = Color(0xFF38BDF8), fontSize = 12.sp)
                                            Text("Tanggal masuk: ${formatDateShort(order.entryDate)}", color = Color(0xFF94A3B8), fontSize = 12.sp)
                                            if (order.complaints.isNotBlank()) {
                                                Text("Keluhan: ${order.complaints}", color = Color(0xFFCBD5E1), fontSize = 12.sp)
                                            }
                                            if (order.repairNotes.isNotBlank()) {
                                                Text("Tindakan: ${order.repairNotes}", color = Color(0xFF94A3B8), fontSize = 12.sp)
                                            }

                                            // Parts installed in this order
                                            if (orderParts.isNotEmpty()) {
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                                                        .padding(8.dp)
                                                ) {
                                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                        Text("Part Terpasang:", color = Color(0xFFF59E0B), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                        orderParts.forEach { part ->
                                                            Text("• ${part.partName} (${part.quantity} ${part.partUnit}) - ${formatRupiah(part.subtotal)}", color = Color.White, fontSize = 11.sp)
                                                        }
                                                    }
                                                }
                                            }

                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("Total Part: ${formatRupiah(order.totalPartCost)}", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                Text("Jasa: ${formatRupiah(order.laborCost)}", color = Color(0xFF94A3B8), fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // ==========================================
                    // MANAJEMEN MEKANIK
                    // ==========================================
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Mekanik Bengkel", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Text("Tim teknisi & spesialisasi perbaikan bus", color = Color(0xFF94A3B8), fontSize = 13.sp)
                                }

                                Button(
                                    onClick = {
                                        mechanicToEdit = null
                                        showAddEditMechanicDialog = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.testTag("add_mechanic_button")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF0F172A))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Tambah", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        if (mechanics.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF1E293B), RoundedCornerShape(12.dp))
                                        .padding(32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("Belum ada mekanik terdaftar.", color = Color(0xFF94A3B8))
                                }
                            }
                        } else {
                            items(mechanics, key = { it.id }) { mech ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF334155), RoundedCornerShape(14.dp))
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(44.dp)
                                                    .background(Color(0xFF0F172A), RoundedCornerShape(10.dp)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(Icons.Default.Engineering, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(24.dp))
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column {
                                                Text(mech.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                                Text(mech.specialization, color = Color(0xFF38BDF8), fontSize = 13.sp)
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.Phone, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(12.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(mech.phone, color = Color(0xFF94A3B8), fontSize = 12.sp)
                                                }
                                            }
                                        }

                                        Row {
                                            IconButton(
                                                onClick = {
                                                    mechanicToEdit = mech
                                                    showAddEditMechanicDialog = true
                                                },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = Color(0xFFF59E0B), modifier = Modifier.size(18.dp))
                                            }
                                            IconButton(
                                                onClick = { mechanicToDelete = mech },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // ==========================================
                    // CADANGAN & PULIHKAN DATA (IMPORT / EXPORT JSON LOKAL)
                    // ==========================================
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item {
                            Text(
                                text = "Cadangan & Pulihkan Data Lokal",
                                color = Color.White,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Ekspor dan impor seluruh data bengkel bus (Armada, Mekanik, Sparepart, SPK, dan Pemakaian) ke berkas JSON lokal untuk backup aman antar perangkat Android.",
                                color = Color(0xFF94A3B8),
                                fontSize = 13.sp
                            )
                        }

                        // Export Section
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF334155), RoundedCornerShape(14.dp))
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Backup, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(24.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Ekspor Cadangan Data (JSON)", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Text(
                                        text = "Simpan salinan cadangan lengkap database SQLite/Room ke media penyimpanan lokal perangkat Android.",
                                        color = Color(0xFFCBD5E1),
                                        fontSize = 12.sp
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                viewModel.exportBackup { json ->
                                                    pendingExportJson = json
                                                    createDocLauncher.launch("bengkelbus_backup_${System.currentTimeMillis()}.json")
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                                            modifier = Modifier.weight(1f).testTag("export_backup_file_button")
                                        ) {
                                            Icon(Icons.Default.Download, contentDescription = null, tint = Color(0xFF0F172A), modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Simpan File", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                viewModel.exportBackup { json ->
                                                    val sendIntent = Intent().apply {
                                                        action = Intent.ACTION_SEND
                                                        putExtra(Intent.EXTRA_TEXT, json)
                                                        type = "text/plain"
                                                    }
                                                    val shareIntent = Intent.createChooser(sendIntent, "Bagikan Data Cadangan BengkelBus")
                                                    context.startActivity(shareIntent)
                                                }
                                            },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.Share, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Bagikan", fontSize = 12.sp)
                                        }
                                    }

                                    Button(
                                        onClick = {
                                            viewModel.exportBackup { json ->
                                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                clipboard.setPrimaryClip(ClipData.newPlainText("BengkelBus Backup", json))
                                                Toast.makeText(context, "Teks JSON berhasil disalin ke papan klip", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Salin Teks JSON Cadangan ke Papan Klip", color = Color.White, fontSize = 12.sp)
                                    }
                                }
                            }
                        }

                        // Restore Section
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF334155), RoundedCornerShape(14.dp))
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Restore, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(24.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Pulihkan Data dari Berkas JSON", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Text(
                                        text = "Pulihkan data bengkel dari berkas backup JSON yang pernah diekspor.",
                                        color = Color(0xFFCBD5E1),
                                        fontSize = 12.sp
                                    )

                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { openDocLauncher.launch(arrayOf("application/json", "text/*")) },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8)),
                                            modifier = Modifier.weight(1f).testTag("select_backup_file_button")
                                        ) {
                                            Text("Pilih Berkas JSON", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                pasteRestoreText = ""
                                                showRestoreDialog = true
                                            },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("Tempel Teks JSON", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }

                        // Seed Sample Workshop Data
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF334155), RoundedCornerShape(14.dp))
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(22.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Muat Data Contoh Bengkel Bus", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Text(
                                        text = "Muat ulang sampel data armada bus Indonesia (Hino, Mercedes-Benz, Scania, Volvo), mekanik, dan inventaris sparepart untuk pengujian.",
                                        color = Color(0xFF94A3B8),
                                        fontSize = 12.sp
                                    )
                                    Button(
                                        onClick = { viewModel.seedSampleData() },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                        modifier = Modifier.fillMaxWidth().testTag("seed_sample_data_button")
                                    ) {
                                        Text("Muat Sampel Data Bengkel", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add / Edit Mechanic Dialog
    if (showAddEditMechanicDialog) {
        AddEditMechanicDialog(
            mechanic = mechanicToEdit,
            onDismiss = { showAddEditMechanicDialog = false },
            onSave = { mech ->
                viewModel.saveMechanic(mech)
                showAddEditMechanicDialog = false
            }
        )
    }

    // Delete Mechanic Dialog
    if (mechanicToDelete != null) {
        val target = mechanicToDelete!!
        AlertDialog(
            onDismissRequest = { mechanicToDelete = null },
            title = { Text("Hapus Mekanik?") },
            text = { Text("Apakah Anda yakin ingin menghapus '${target.name}' (${target.specialization})?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteMechanic(target.id)
                        mechanicToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("Hapus", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { mechanicToDelete = null }) { Text("Batal") }
            },
            containerColor = Color(0xFF1E293B),
            titleContentColor = Color.White,
            textContentColor = Color(0xFFCBD5E1)
        )
    }

    // Restore Confirmation Dialog
    if (showRestoreDialog) {
        var replaceAll by remember { mutableStateOf(true) }

        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = { Text("Pulihkan Data Database", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Pastikan format data JSON sesuai. Pilih apakah ingin menimpa seluruh database atau menggabungkannya.",
                        color = Color(0xFFCBD5E1),
                        fontSize = 13.sp
                    )

                    OutlinedTextField(
                        value = pasteRestoreText,
                        onValueChange = { pasteRestoreText = it },
                        label = { Text("Konten JSON Cadangan") },
                        placeholder = { Text("{\"app\": \"BengkelBus App\", ...}") },
                        modifier = Modifier.fillMaxWidth().height(160.dp),
                        colors = dialogTextFieldColors()
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { replaceAll = !replaceAll },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (replaceAll) "Mode: Ganti Semua Data (Recommended)" else "Mode: Tambah ke Data Yang Ada",
                            color = Color(0xFFF59E0B),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (pasteRestoreText.isNotBlank()) {
                            viewModel.restoreBackup(pasteRestoreText.trim(), replaceAll)
                            showRestoreDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                    enabled = pasteRestoreText.isNotBlank(),
                    modifier = Modifier.testTag("confirm_restore_button")
                ) {
                    Text("Pulihkan Sekarang", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showRestoreDialog = false }) { Text("Batal") }
            },
            containerColor = Color(0xFF1E293B),
            titleContentColor = Color.White,
            textContentColor = Color(0xFFCBD5E1)
        )
    }
}

@Composable
fun AddEditMechanicDialog(
    mechanic: MechanicEntity?,
    onDismiss: () -> Unit,
    onSave: (MechanicEntity) -> Unit
) {
    val isEdit = mechanic != null

    var name by remember { mutableStateOf(mechanic?.name ?: "") }
    var specialization by remember { mutableStateOf(mechanic?.specialization ?: "Mesin & Transmisi") }
    var phone by remember { mutableStateOf(mechanic?.phone ?: "0812-") }
    var status by remember { mutableStateOf(mechanic?.status ?: "Aktif") }
    var joinedYearStr by remember { mutableStateOf(mechanic?.joinedYear?.toString() ?: "2021") }

    val specializations = listOf(
        "Mesin & Transmisi",
        "Sistem Rem Tromol & Balon Udara",
        "Kelistrikan Bus & AC Denso",
        "Chasis, Roda & Kaki-kaki",
        "Perbaikan Bodi & Karoseri"
    )

    var specExpanded by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isEdit) "Edit Mekanik" else "Tambah Mekanik Baru",
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (errorMessage != null) {
                    Text(text = errorMessage!!, color = Color(0xFFEF4444), fontSize = 12.sp)
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Mekanik") },
                    placeholder = { Text("Contoh: Bambang Sudiro") },
                    modifier = Modifier.fillMaxWidth().testTag("mechanic_name_input"),
                    colors = dialogTextFieldColors()
                )

                OutlinedTextField(
                    value = specialization,
                    onValueChange = { specialization = it },
                    label = { Text("Spesialisasi / Keahlian") },
                    placeholder = { Text("Contoh: Mesin & Transmisi") },
                    modifier = Modifier.fillMaxWidth().testTag("mechanic_specialization_input"),
                    colors = dialogTextFieldColors()
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Nomor Telepon / HP") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth().testTag("mechanic_phone_input"),
                    colors = dialogTextFieldColors()
                )

                OutlinedTextField(
                    value = joinedYearStr,
                    onValueChange = { joinedYearStr = it },
                    label = { Text("Tahun Bergabung") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    colors = dialogTextFieldColors()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        errorMessage = "Nama mekanik tidak boleh kosong"
                        return@Button
                    }
                    val year = joinedYearStr.toIntOrNull() ?: 2020

                    onSave(
                        MechanicEntity(
                            id = mechanic?.id ?: 0L,
                            name = name.trim(),
                            specialization = specialization.trim(),
                            phone = phone.trim(),
                            status = status,
                            joinedYear = year,
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                modifier = Modifier.testTag("save_mechanic_button")
            ) {
                Text("Simpan Mekanik", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("Batal") }
        },
        containerColor = Color(0xFF1E293B),
        titleContentColor = Color.White,
        textContentColor = Color(0xFFCBD5E1)
    )
}
