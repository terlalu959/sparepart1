package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val WorkshopAmber = Color(0xFFF59E0B)
val WorkshopAmberDark = Color(0xFFD97706)
val WorkshopAmberLight = Color(0xFFFDE68A)

val WorkshopDarkBg = Color(0xFF0B1120)
val WorkshopSurface = Color(0xFF1E293B)
val WorkshopSurfaceVariant = Color(0xFF334155)

val StatusReadyGreen = Color(0xFF10B981)
val StatusRepairYellow = Color(0xFFF59E0B)
val StatusDueOrange = Color(0xFFF97316)
val StatusDangerRed = Color(0xFFEF4444)
val AccentCyan = Color(0xFF06B6D4)

val TextWhite = Color(0xFFF8FAFC)
val TextMuted = Color(0xFF94A3B8)
val BorderSubtle = Color(0xFF334155)
