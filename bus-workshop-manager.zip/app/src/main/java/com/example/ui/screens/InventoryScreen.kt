package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sell
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.SparepartEntity
import com.example.ui.components.StockBadge
import com.example.ui.components.formatRupiah
import com.example.ui.viewmodel.WorkshopViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryScreen(
    viewModel: WorkshopViewModel,
    onOpenScanner: () -> Unit,
    modifier: Modifier = Modifier
) {
    val spareparts by viewModel.spareparts.collectAsStateWithLifecycle()
    val searchQuery by viewModel.partSearchQuery.collectAsStateWithLifecycle()
    val categoryFilter by viewModel.partCategoryFilter.collectAsStateWithLifecycle()
    val onlyLowStock by viewModel.partOnlyLowStock.collectAsStateWithLifecycle()
    val scannedBarcode by viewModel.scannedBarcode.collectAsStateWithLifecycle()

    var showAddEditDialog by remember { mutableStateOf(false) }
    var partToEdit by remember { mutableStateOf<SparepartEntity?>(null) }
    var partToDelete by remember { mutableStateOf<SparepartEntity?>(null) }
    var adjustStockPart by remember { mutableStateOf<SparepartEntity?>(null) }
    var prefilledBarcode by remember { mutableStateOf<String?>(null) }

    // Check if there was a recent scanned barcode
    if (scannedBarcode != null) {
        val found = spareparts.find { it.partCode.equals(scannedBarcode, ignoreCase = true) }
        if (found != null) {
            adjustStockPart = found
            viewModel.clearScannedBarcode()
        } else {
            prefilledBarcode = scannedBarcode
            partToEdit = null
            showAddEditDialog = true
            viewModel.clearScannedBarcode()
        }
    }

    val categories = listOf("Semua", "Pengereman", "Mesin & Pelumas", "Suspensi & Balon", "Kelistrikan", "Filter", "Transmisi")

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B1120))
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header with Scan Barcode and Add Part
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Gudang & Sparepart",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${spareparts.size} jenis suku cadang bus tercatat",
                            color = Color(0xFF94A3B8),
                            fontSize = 13.sp
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = onOpenScanner,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .border(1.dp, Color(0xFFF59E0B), RoundedCornerShape(10.dp))
                                .testTag("inventory_scanner_button")
                        ) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan", tint = Color(0xFFF59E0B), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Scan", color = Color(0xFFF59E0B), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                partToEdit = null
                                prefilledBarcode = null
                                showAddEditDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("add_part_top_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF0F172A), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Tambah", color = Color(0xFF0F172A), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setPartSearchQuery(it) },
                    placeholder = { Text("Cari kode barcode, nama part, atau lokasi rak...") },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF94A3B8))
                    },
                    modifier = Modifier.fillMaxWidth().testTag("part_search_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = dialogTextFieldColors(),
                    singleLine = true
                )
            }

            // Category & Low Stock Filter Row
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Kategori Sparepart:",
                            color = Color(0xFF94A3B8),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )

                        FilterChip(
                            selected = onlyLowStock,
                            onClick = { viewModel.setPartOnlyLowStock(!onlyLowStock) },
                            label = { Text("Hanya Stok Menipis", fontSize = 11.sp) },
                            leadingIcon = {
                                Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(14.dp))
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF7F1D1D),
                                selectedLabelColor = Color(0xFFFCA5A5),
                                containerColor = Color(0xFF1E293B),
                                labelColor = Color(0xFFCBD5E1)
                            )
                        )
                    }

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(categories) { cat ->
                            val isSelected = categoryFilter == cat
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.setPartCategoryFilter(cat) },
                                label = { Text(cat, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFF59E0B),
                                    selectedLabelColor = Color(0xFF0F172A),
                                    containerColor = Color(0xFF1E293B),
                                    labelColor = Color(0xFFCBD5E1)
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    borderColor = if (isSelected) Color(0xFFF59E0B) else Color(0xFF334155)
                                )
                            )
                        }
                    }
                }
            }

            // Parts List
            if (spareparts.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Inventory2,
                                contentDescription = null,
                                tint = Color(0xFF64748B),
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Tidak ada sparepart ditemukan",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "Coba ubah kata kunci atau scan barcode baru.",
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            } else {
                items(spareparts, key = { it.id }) { part ->
                    SparepartItemCard(
                        part = part,
                        onAdjustStock = { adjustStockPart = part },
                        onEdit = {
                            partToEdit = part
                            prefilledBarcode = null
                            showAddEditDialog = true
                        },
                        onDelete = { partToDelete = part }
                    )
                }
            }
        }
    }

    // Add / Edit Sparepart Dialog
    if (showAddEditDialog) {
        AddEditSparepartDialog(
            part = partToEdit,
            prefilledBarcode = prefilledBarcode,
            onDismiss = { showAddEditDialog = false },
            onOpenScanner = onOpenScanner,
            onSave = { part ->
                viewModel.saveSparepart(part)
                showAddEditDialog = false
            }
        )
    }

    // Adjust Stock Dialog
    if (adjustStockPart != null) {
        val part = adjustStockPart!!
        var adjustAmountStr by remember { mutableStateOf("1") }

        AlertDialog(
            onDismissRequest = { adjustStockPart = null },
            title = {
                Text("Atur Stok: ${part.name}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Kode Barcode: ${part.partCode}\nStok Saat Ini: ${part.stock} ${part.unit}\nLokasi: ${part.shelfLocation}",
                        color = Color(0xFFCBD5E1),
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = adjustAmountStr,
                        onValueChange = { adjustAmountStr = it },
                        label = { Text("Jumlah Penyesuaian (${part.unit})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("adjust_stock_input"),
                        colors = dialogTextFieldColors()
                    )
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val amount = adjustAmountStr.toIntOrNull() ?: 1
                            viewModel.adjustPartStock(part.id, -amount)
                            adjustStockPart = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Kurangi Stok")
                    }

                    Button(
                        onClick = {
                            val amount = adjustAmountStr.toIntOrNull() ?: 1
                            viewModel.adjustPartStock(part.id, amount)
                            adjustStockPart = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                        modifier = Modifier.testTag("confirm_increase_stock_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Tambah Stok")
                    }
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { adjustStockPart = null }) {
                    Text("Tutup")
                }
            },
            containerColor = Color(0xFF1E293B),
            titleContentColor = Color.White,
            textContentColor = Color(0xFFCBD5E1)
        )
    }

    // Delete Confirmation Dialog
    if (partToDelete != null) {
        val target = partToDelete!!
        AlertDialog(
            onDismissRequest = { partToDelete = null },
            title = { Text("Hapus Sparepart?") },
            text = { Text("Apakah Anda yakin ingin menghapus '${target.name}' (${target.partCode}) dari gudang?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteSparepart(target.id)
                        partToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                    modifier = Modifier.testTag("confirm_delete_part_button")
                ) {
                    Text("Hapus Part", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { partToDelete = null }) {
                    Text("Batal")
                }
            },
            containerColor = Color(0xFF1E293B),
            titleContentColor = Color.White,
            textContentColor = Color(0xFFCBD5E1)
        )
    }
}

@Composable
fun SparepartItemCard(
    part: SparepartEntity,
    onAdjustStock: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(14.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = part.partCode,
                            color = Color(0xFFF59E0B),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = part.category,
                        color = Color(0xFF94A3B8),
                        fontSize = 12.sp
                    )
                }

                StockBadge(stock = part.stock, minStock = part.minStock, unit = part.unit)
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = part.name,
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = part.shelfLocation,
                        color = Color(0xFF38BDF8),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Text(
                    text = "${formatRupiah(part.unitPrice)} / ${part.unit}",
                    color = Color(0xFF10B981),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onAdjustStock,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(34.dp).testTag("adjust_stock_btn_${part.id}")
                ) {
                    Text("Atur Stok", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Row {
                    IconButton(onClick = onEdit, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Part", tint = Color(0xFFF59E0B), modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Hapus Part", tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditSparepartDialog(
    part: SparepartEntity?,
    prefilledBarcode: String? = null,
    onDismiss: () -> Unit,
    onOpenScanner: () -> Unit,
    onSave: (SparepartEntity) -> Unit
) {
    val isEdit = part != null

    var partCode by remember {
        mutableStateOf(part?.partCode ?: prefilledBarcode ?: "")
    }
    var name by remember { mutableStateOf(part?.name ?: "") }
    var category by remember { mutableStateOf(part?.category ?: "Pengereman") }
    var stockStr by remember { mutableStateOf(part?.stock?.toString() ?: "10") }
    var minStockStr by remember { mutableStateOf(part?.minStock?.toString() ?: "2") }
    var unit by remember { mutableStateOf(part?.unit ?: "Pcs") }
    var priceStr by remember { mutableStateOf(part?.unitPrice?.toInt()?.toString() ?: "150000") }
    var shelfLocation by remember { mutableStateOf(part?.shelfLocation ?: "Rak A-01") }

    val categories = listOf("Pengereman", "Mesin & Pelumas", "Suspensi & Balon", "Kelistrikan", "Filter", "Transmisi", "Lainnya")
    val units = listOf("Pcs", "Set", "Liter", "Box", "Meter")

    var categoryExpanded by remember { mutableStateOf(false) }
    var unitExpanded by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isEdit) "Edit Data Sparepart" else "Tambah Sparepart Baru",
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (errorMessage != null) {
                    Text(text = errorMessage!!, color = Color(0xFFEF4444), fontSize = 12.sp)
                }

                // Part Code with Scan Barcode Quick Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = partCode,
                        onValueChange = { partCode = it.uppercase() },
                        label = { Text("Kode Barcode / Part Number") },
                        placeholder = { Text("Contoh: BRK-PAD-1626") },
                        modifier = Modifier.weight(1f).testTag("part_code_input"),
                        colors = dialogTextFieldColors()
                    )

                    IconButton(
                        onClick = onOpenScanner,
                        modifier = Modifier
                            .size(52.dp)
                            .background(Color(0xFF334155), RoundedCornerShape(10.dp))
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan", tint = Color(0xFFF59E0B))
                    }
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Sparepart") },
                    placeholder = { Text("Contoh: Kampas Rem Depan OH 1626") },
                    modifier = Modifier.fillMaxWidth().testTag("part_name_input"),
                    colors = dialogTextFieldColors()
                )

                // Category Dropdown
                ExposedDropdownMenuBox(
                    expanded = categoryExpanded,
                    onExpandedChange = { categoryExpanded = !categoryExpanded }
                ) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Kategori") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        colors = dialogTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = categoryExpanded,
                        onDismissRequest = { categoryExpanded = false },
                        modifier = Modifier.background(Color(0xFF1E293B))
                    ) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat, color = Color.White) },
                                onClick = {
                                    category = cat
                                    categoryExpanded = false
                                }
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = stockStr,
                        onValueChange = { stockStr = it },
                        label = { Text("Stok Fisik") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("part_stock_input"),
                        colors = dialogTextFieldColors()
                    )

                    OutlinedTextField(
                        value = minStockStr,
                        onValueChange = { minStockStr = it },
                        label = { Text("Min Stok") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = dialogTextFieldColors()
                    )

                    // Unit selector
                    ExposedDropdownMenuBox(
                        expanded = unitExpanded,
                        onExpandedChange = { unitExpanded = !unitExpanded },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = unit,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Satuan") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = unitExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth(),
                            colors = dialogTextFieldColors()
                        )
                        ExposedDropdownMenu(
                            expanded = unitExpanded,
                            onDismissRequest = { unitExpanded = false },
                            modifier = Modifier.background(Color(0xFF1E293B))
                        ) {
                            units.forEach { u ->
                                DropdownMenuItem(
                                    text = { Text(u, color = Color.White) },
                                    onClick = {
                                        unit = u
                                        unitExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = priceStr,
                        onValueChange = { priceStr = it },
                        label = { Text("Harga Satuan (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1.2f).testTag("part_price_input"),
                        colors = dialogTextFieldColors()
                    )

                    OutlinedTextField(
                        value = shelfLocation,
                        onValueChange = { shelfLocation = it },
                        label = { Text("Lokasi Rak") },
                        placeholder = { Text("Rak A-01") },
                        modifier = Modifier.weight(1f).testTag("part_location_input"),
                        colors = dialogTextFieldColors()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (partCode.isBlank()) {
                        errorMessage = "Kode part / barcode tidak boleh kosong"
                        return@Button
                    }
                    if (name.isBlank()) {
                        errorMessage = "Nama sparepart tidak boleh kosong"
                        return@Button
                    }
                    val stock = stockStr.toIntOrNull() ?: 0
                    val minStock = minStockStr.toIntOrNull() ?: 2
                    val price = priceStr.toDoubleOrNull() ?: 0.0

                    onSave(
                        SparepartEntity(
                            id = part?.id ?: 0L,
                            partCode = partCode.trim(),
                            name = name.trim(),
                            category = category,
                            stock = stock,
                            minStock = minStock,
                            unit = unit,
                            unitPrice = price,
                            shelfLocation = shelfLocation.trim(),
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                modifier = Modifier.testTag("save_part_button")
            ) {
                Text("Simpan Sparepart", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        },
        containerColor = Color(0xFF1E293B),
        titleContentColor = Color.White,
        textContentColor = Color(0xFFCBD5E1)
    )
}
