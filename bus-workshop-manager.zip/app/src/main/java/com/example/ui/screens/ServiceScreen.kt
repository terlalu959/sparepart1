package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.BusEntity
import com.example.data.local.entity.MechanicEntity
import com.example.data.local.entity.ServiceOrderEntity
import com.example.data.local.entity.SparepartEntity
import com.example.ui.components.SpkStatusBadge
import com.example.ui.components.formatDate
import com.example.ui.components.formatDateShort
import com.example.ui.components.formatRupiah
import com.example.ui.viewmodel.WorkshopViewModel
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServiceScreen(
    viewModel: WorkshopViewModel,
    preselectedOrderId: Long? = null,
    onOpenScanner: () -> Unit,
    modifier: Modifier = Modifier
) {
    val allOrders by viewModel.serviceOrders.collectAsStateWithLifecycle()
    val allBuses by viewModel.buses.collectAsStateWithLifecycle()
    val allMechanics by viewModel.mechanics.collectAsStateWithLifecycle()
    val allParts by viewModel.spareparts.collectAsStateWithLifecycle()
    val statusFilter by viewModel.serviceStatusFilter.collectAsStateWithLifecycle()

    var showAddEditOrderDialog by remember { mutableStateOf(false) }
    var orderToEdit by remember { mutableStateOf<ServiceOrderEntity?>(null) }
    var orderToDelete by remember { mutableStateOf<ServiceOrderEntity?>(null) }
    var detailOrderId by remember { mutableStateOf(preselectedOrderId) }

    // Dialog for adding sparepart usage to active SPK
    var showAddPartUsageDialog by remember { mutableStateOf(false) }
    var completeOrderDialog by remember { mutableStateOf<ServiceOrderEntity?>(null) }

    val filterOptions = listOf("Semua", "Aktif", "Dikerjakan", "Menunggu Part", "Selesai")

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B1120))
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Pencatatan Servis & SPK",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Surat Perintah Kerja per unit bus & pemakaian part",
                            color = Color(0xFF94A3B8),
                            fontSize = 13.sp
                        )
                    }

                    Button(
                        onClick = {
                            orderToEdit = null
                            showAddEditOrderDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("add_spk_top_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF0F172A))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("SPK Baru", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Filter Chips
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filterOptions) { filter ->
                        val isSelected = statusFilter == filter
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setServiceStatusFilter(filter) },
                            label = { Text(filter, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFFF59E0B),
                                selectedLabelColor = Color(0xFF0F172A),
                                containerColor = Color(0xFF1E293B),
                                labelColor = Color(0xFFCBD5E1)
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) Color(0xFFF59E0B) else Color(0xFF334155)
                            )
                        )
                    }
                }
            }

            // List of Orders
            if (allOrders.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Build,
                                contentDescription = null,
                                tint = Color(0xFF64748B),
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Tidak Ada SPK Servis",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "Klik tombol 'SPK Baru' untuk mencatat perbaikan unit bus.",
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            } else {
                items(allOrders, key = { it.id }) { order ->
                    val bus = allBuses.find { it.id == order.busId }
                    val mechanic = allMechanics.find { it.id == order.mechanicId }

                    ServiceOrderItemCard(
                        order = order,
                        bus = bus,
                        mechanic = mechanic,
                        onClick = { detailOrderId = order.id },
                        onEdit = {
                            orderToEdit = order
                            showAddEditOrderDialog = true
                        },
                        onDelete = { orderToDelete = order },
                        onComplete = { completeOrderDialog = order }
                    )
                }
            }
        }
    }

    // Add / Edit SPK Dialog
    if (showAddEditOrderDialog) {
        AddEditServiceOrderDialog(
            order = orderToEdit,
            buses = allBuses,
            mechanics = allMechanics,
            onDismiss = { showAddEditOrderDialog = false },
            onSave = { order ->
                viewModel.saveServiceOrder(order)
                showAddEditOrderDialog = false
            }
        )
    }

    // Delete Confirmation
    if (orderToDelete != null) {
        val target = orderToDelete!!
        AlertDialog(
            onDismissRequest = { orderToDelete = null },
            title = { Text("Hapus SPK Servis?") },
            text = { Text("Apakah Anda yakin ingin menghapus ${target.spkNumber}? Riwayat pemakaian part pada SPK ini akan terhapus.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteServiceOrder(target.id)
                        orderToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                    modifier = Modifier.testTag("confirm_delete_spk_button")
                ) {
                    Text("Hapus SPK", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { orderToDelete = null }) {
                    Text("Batal")
                }
            },
            containerColor = Color(0xFF1E293B),
            titleContentColor = Color.White,
            textContentColor = Color(0xFFCBD5E1)
        )
    }

    // Selesaikan SPK Dialog
    if (completeOrderDialog != null) {
        val order = completeOrderDialog!!
        var notes by remember { mutableStateOf(order.repairNotes) }

        AlertDialog(
            onDismissRequest = { completeOrderDialog = null },
            title = { Text("Selesaikan SPK ${order.spkNumber}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Tandai pekerjaan perbaikan ini sebagai selesai. Status unit bus akan otomatis diubah menjadi 'Siap Jalan'.")
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Catatan Hasil Pengerjaan / Saran") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3,
                        colors = dialogTextFieldColors()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.completeServiceOrder(order.id, notes)
                        completeOrderDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    modifier = Modifier.testTag("confirm_complete_spk_button")
                ) {
                    Text("Tandai Selesai", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { completeOrderDialog = null }) {
                    Text("Batal")
                }
            },
            containerColor = Color(0xFF1E293B),
            titleContentColor = Color.White,
            textContentColor = Color(0xFFCBD5E1)
        )
    }

    // Detail SPK Dialog (Termasuk Pencatatan & Riwayat Pemakaian Part)
    if (detailOrderId != null) {
        val currentOrder = allOrders.find { it.id == detailOrderId }
        if (currentOrder != null) {
            val bus = allBuses.find { it.id == currentOrder.busId }
            val mechanic = allMechanics.find { it.id == currentOrder.mechanicId }

            viewModel.selectServiceOrderForDetails(currentOrder.id)
            val partUsages by viewModel.selectedOrderPartUsages.collectAsStateWithLifecycle()

            ServiceOrderDetailDialog(
                order = currentOrder,
                bus = bus,
                mechanic = mechanic,
                partUsages = partUsages,
                onDismiss = {
                    detailOrderId = null
                    viewModel.selectServiceOrderForDetails(null)
                },
                onAddPartUsage = { showAddPartUsageDialog = true },
                onRemovePartUsage = { usageId -> viewModel.removePartUsage(usageId) },
                onCompleteSpk = { completeOrderDialog = currentOrder }
            )

            // Add Part Usage Dialog inside Detail
            if (showAddPartUsageDialog) {
                AddPartUsageDialog(
                    order = currentOrder,
                    availableParts = allParts,
                    onDismiss = { showAddPartUsageDialog = false },
                    onOpenScanner = onOpenScanner,
                    onSave = { partId, qty, notes ->
                        viewModel.recordPartUsage(
                            serviceOrderId = currentOrder.id,
                            sparepartId = partId,
                            busId = currentOrder.busId,
                            quantity = qty,
                            notes = notes
                        )
                        showAddPartUsageDialog = false
                    }
                )
            }
        }
    }
}

@Composable
fun ServiceOrderItemCard(
    order: ServiceOrderEntity,
    bus: BusEntity?,
    mechanic: MechanicEntity?,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onComplete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(14.dp))
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = order.spkNumber,
                        color = Color(0xFFF59E0B),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = bus?.plateNumber ?: "Bus #${order.busId}",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = bus?.model ?: "",
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp,
                        maxLines = 1
                    )
                }

                SpkStatusBadge(status = order.status)
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = order.serviceType,
                color = Color(0xFFE2E8F0),
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )

            if (order.complaints.isNotBlank()) {
                Text(
                    text = "Keluhan: ${order.complaints}",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp,
                    maxLines = 2
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Mekanik: ${mechanic?.name ?: "Belum ditugaskan"}",
                        color = Color(0xFF38BDF8),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Masuk: ${formatDateShort(order.entryDate)}",
                        color = Color(0xFF64748B),
                        fontSize = 11.sp
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Biaya Part: ${formatRupiah(order.totalPartCost)}",
                        color = Color(0xFF10B981),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (order.laborCost > 0) {
                        Text(
                            text = "Jasa: ${formatRupiah(order.laborCost)}",
                            color = Color(0xFFCBD5E1),
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (order.status != "Selesai") {
                    Button(
                        onClick = onComplete,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Selesaikan", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                }

                IconButton(onClick = onEdit, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit", tint = Color(0xFFF59E0B), modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditServiceOrderDialog(
    order: ServiceOrderEntity?,
    buses: List<BusEntity>,
    mechanics: List<MechanicEntity>,
    onDismiss: () -> Unit,
    onSave: (ServiceOrderEntity) -> Unit
) {
    val isEdit = order != null

    var spkNumber by remember {
        mutableStateOf(order?.spkNumber ?: "SPK-${System.currentTimeMillis().toString().takeLast(5)}")
    }
    var selectedBusId by remember {
        mutableLongStateOf(order?.busId ?: (buses.firstOrNull()?.id ?: 0L))
    }
    var selectedMechanicId by remember {
        mutableStateOf(order?.mechanicId ?: mechanics.firstOrNull()?.id)
    }
    var serviceType by remember {
        mutableStateOf(order?.serviceType ?: "Servis Berkala")
    }
    var entryOdometerStr by remember {
        val bus = buses.find { it.id == selectedBusId }
        mutableStateOf(order?.entryOdometer?.toString() ?: (bus?.lastOdometer?.toString() ?: "100000"))
    }
    var complaints by remember { mutableStateOf(order?.complaints ?: "") }
    var repairNotes by remember { mutableStateOf(order?.repairNotes ?: "") }
    var laborCostStr by remember { mutableStateOf(order?.laborCost?.toInt()?.toString() ?: "0") }
    var status by remember { mutableStateOf(order?.status ?: "Dikerjakan") }

    val serviceTypeOptions = listOf(
        "Servis Rutin / Berkala",
        "Perbaikan Rem & Kaki-kaki",
        "Overhaul Mesin & Transmisi",
        "Perbaikan AC & Kelistrikan",
        "Breakdown / Darurat Jalan",
        "Penggantian Ban & Suspensi"
    )

    var busExpanded by remember { mutableStateOf(false) }
    var mechanicExpanded by remember { mutableStateOf(false) }
    var typeExpanded by remember { mutableStateOf(false) }
    var statusExpanded by remember { mutableStateOf(false) }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isEdit) "Edit SPK Servis" else "Buat SPK Servis Baru",
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (errorMessage != null) {
                    Text(text = errorMessage!!, color = Color(0xFFEF4444), fontSize = 12.sp)
                }

                OutlinedTextField(
                    value = spkNumber,
                    onValueChange = { spkNumber = it.uppercase() },
                    label = { Text("Nomor SPK") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = dialogTextFieldColors()
                )

                // Bus Selector Dropdown
                ExposedDropdownMenuBox(
                    expanded = busExpanded,
                    onExpandedChange = { busExpanded = !busExpanded }
                ) {
                    val currentBus = buses.find { it.id == selectedBusId }
                    OutlinedTextField(
                        value = currentBus?.let { "${it.plateNumber} (${it.model})" } ?: "Pilih Unit Bus",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Unit Bus Armada") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = busExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        colors = dialogTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = busExpanded,
                        onDismissRequest = { busExpanded = false },
                        modifier = Modifier.background(Color(0xFF1E293B))
                    ) {
                        buses.forEach { bus ->
                            DropdownMenuItem(
                                text = { Text("${bus.plateNumber} - ${bus.model}", color = Color.White) },
                                onClick = {
                                    selectedBusId = bus.id
                                    entryOdometerStr = bus.lastOdometer.toString()
                                    busExpanded = false
                                }
                            )
                        }
                    }
                }

                // Mechanic Selector Dropdown
                ExposedDropdownMenuBox(
                    expanded = mechanicExpanded,
                    onExpandedChange = { mechanicExpanded = !mechanicExpanded }
                ) {
                    val currentMech = mechanics.find { it.id == selectedMechanicId }
                    OutlinedTextField(
                        value = currentMech?.name ?: "Pilih Mekanik",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Mekanik Bertugas") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = mechanicExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        colors = dialogTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = mechanicExpanded,
                        onDismissRequest = { mechanicExpanded = false },
                        modifier = Modifier.background(Color(0xFF1E293B))
                    ) {
                        mechanics.forEach { mech ->
                            DropdownMenuItem(
                                text = { Text("${mech.name} (${mech.specialization})", color = Color.White) },
                                onClick = {
                                    selectedMechanicId = mech.id
                                    mechanicExpanded = false
                                }
                            )
                        }
                    }
                }

                // Service Type Dropdown
                ExposedDropdownMenuBox(
                    expanded = typeExpanded,
                    onExpandedChange = { typeExpanded = !typeExpanded }
                ) {
                    OutlinedTextField(
                        value = serviceType,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Jenis Pekerjaan Servis") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        colors = dialogTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = typeExpanded,
                        onDismissRequest = { typeExpanded = false },
                        modifier = Modifier.background(Color(0xFF1E293B))
                    ) {
                        serviceTypeOptions.forEach { opt ->
                            DropdownMenuItem(
                                text = { Text(opt, color = Color.White) },
                                onClick = {
                                    serviceType = opt
                                    typeExpanded = false
                                }
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = entryOdometerStr,
                        onValueChange = { entryOdometerStr = it },
                        label = { Text("Odo Masuk (km)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = dialogTextFieldColors()
                    )

                    OutlinedTextField(
                        value = laborCostStr,
                        onValueChange = { laborCostStr = it },
                        label = { Text("Jasa (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = dialogTextFieldColors()
                    )
                }

                OutlinedTextField(
                    value = complaints,
                    onValueChange = { complaints = it },
                    label = { Text("Keluhan Pengemudi / Gejala") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2,
                    colors = dialogTextFieldColors()
                )

                OutlinedTextField(
                    value = repairNotes,
                    onValueChange = { repairNotes = it },
                    label = { Text("Rencana Tindakan / Catatan Teknisi") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2,
                    colors = dialogTextFieldColors()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (spkNumber.isBlank()) {
                        errorMessage = "Nomor SPK tidak boleh kosong"
                        return@Button
                    }
                    if (selectedBusId == 0L) {
                        errorMessage = "Pilih unit bus terlebih dahulu"
                        return@Button
                    }
                    val odo = entryOdometerStr.toIntOrNull() ?: 0
                    val labor = laborCostStr.toDoubleOrNull() ?: 0.0

                    onSave(
                        ServiceOrderEntity(
                            id = order?.id ?: 0L,
                            spkNumber = spkNumber.trim(),
                            busId = selectedBusId,
                            mechanicId = selectedMechanicId,
                            serviceType = serviceType,
                            entryOdometer = odo,
                            entryDate = order?.entryDate ?: System.currentTimeMillis(),
                            exitDate = order?.exitDate,
                            status = status,
                            complaints = complaints.trim(),
                            repairNotes = repairNotes.trim(),
                            laborCost = labor,
                            totalPartCost = order?.totalPartCost ?: 0.0,
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                modifier = Modifier.testTag("save_spk_button")
            ) {
                Text("Simpan SPK", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        },
        containerColor = Color(0xFF1E293B),
        titleContentColor = Color.White,
        textContentColor = Color(0xFFCBD5E1)
    )
}

@Composable
fun ServiceOrderDetailDialog(
    order: ServiceOrderEntity,
    bus: BusEntity?,
    mechanic: MechanicEntity?,
    partUsages: List<com.example.data.model.PartUsageDetail>,
    onDismiss: () -> Unit,
    onAddPartUsage: () -> Unit,
    onRemovePartUsage: (Long) -> Unit,
    onCompleteSpk: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(order.spkNumber, color = Color(0xFFF59E0B), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(bus?.plateNumber ?: "Bus #${order.busId}", color = Color.White, fontSize = 14.sp)
                }
                SpkStatusBadge(status = order.status)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Info Section
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Pekerjaan:", color = Color(0xFF94A3B8), fontSize = 12.sp)
                                Text(order.serviceType, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Mekanik:", color = Color(0xFF94A3B8), fontSize = 12.sp)
                                Text(mechanic?.name ?: "-", color = Color(0xFF38BDF8), fontSize = 12.sp)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Odometer Masuk:", color = Color(0xFF94A3B8), fontSize = 12.sp)
                                Text("${order.entryOdometer} km", color = Color.White, fontSize = 12.sp)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Waktu Masuk:", color = Color(0xFF94A3B8), fontSize = 12.sp)
                                Text(formatDate(order.entryDate), color = Color.White, fontSize = 12.sp)
                            }
                            if (order.exitDate != null) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Waktu Selesai:", color = Color(0xFF94A3B8), fontSize = 12.sp)
                                    Text(formatDate(order.exitDate), color = Color(0xFF10B981), fontSize = 12.sp)
                                }
                            }
                            if (order.complaints.isNotBlank()) {
                                Text("Keluhan: ${order.complaints}", color = Color(0xFFCBD5E1), fontSize = 12.sp)
                            }
                        }
                    }
                }

                // Sparepart Usage Section Header
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PEMAKAIAN PART (${partUsages.size})",
                            color = Color(0xFFF59E0B),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Button(
                            onClick = onAddPartUsage,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("open_add_part_usage_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF0F172A), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Pakai Part", color = Color(0xFF0F172A), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Sparepart Usage List
                if (partUsages.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Belum ada sparepart dicatat untuk SPK ini.\nKlik 'Pakai Part' untuk mencatat pemakaian.",
                                color = Color(0xFF64748B),
                                fontSize = 12.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                } else {
                    items(partUsages, key = { it.id }) { usage ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = usage.partName,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${usage.partCode} • ${usage.quantity} ${usage.partUnit} @ ${formatRupiah(usage.unitPrice)}",
                                        color = Color(0xFF94A3B8),
                                        fontSize = 11.sp
                                    )
                                    if (usage.notes.isNotBlank()) {
                                        Text(text = "Ket: ${usage.notes}", color = Color(0xFFCBD5E1), fontSize = 11.sp)
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = formatRupiah(usage.subtotal),
                                        color = Color(0xFF10B981),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    IconButton(
                                        onClick = { onRemovePartUsage(usage.id) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Hapus Pemakaian Part",
                                            tint = Color(0xFFEF4444),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Total Cost Summary
                item {
                    val grandTotal = order.totalPartCost + order.laborCost
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(10.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Biaya Sparepart:", color = Color(0xFF94A3B8), fontSize = 12.sp)
                                Text(formatRupiah(order.totalPartCost), color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Biaya Jasa / Ongkos Kerja:", color = Color(0xFF94A3B8), fontSize = 12.sp)
                                Text(formatRupiah(order.laborCost), color = Color.White, fontSize = 12.sp)
                            }
                            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF334155)))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("TOTAL ESTIMASI BIAYA:", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(formatRupiah(grandTotal), color = Color(0xFFF59E0B), fontSize = 14.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (order.status != "Selesai") {
                Button(
                    onClick = onCompleteSpk,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Selesaikan SPK", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Tutup")
            }
        },
        containerColor = Color(0xFF1E293B),
        titleContentColor = Color.White,
        textContentColor = Color(0xFFCBD5E1)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPartUsageDialog(
    order: ServiceOrderEntity,
    availableParts: List<SparepartEntity>,
    onDismiss: () -> Unit,
    onOpenScanner: () -> Unit,
    onSave: (partId: Long, quantity: Int, notes: String) -> Unit
) {
    var selectedPartId by remember {
        mutableLongStateOf(availableParts.firstOrNull()?.id ?: 0L)
    }
    var quantityStr by remember { mutableStateOf("1") }
    var notes by remember { mutableStateOf("") }
    var partDropdownExpanded by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val selectedPart = availableParts.find { it.id == selectedPartId }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Catat Pemakaian Sparepart", color = Color.White, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Catat suku cadang yang dipasang pada unit bus. Stok gudang akan otomatis dipotong secara realtime.",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp
                )

                if (errorMessage != null) {
                    Text(text = errorMessage!!, color = Color(0xFFEF4444), fontSize = 12.sp)
                }

                // Part Dropdown & Scan button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ExposedDropdownMenuBox(
                        expanded = partDropdownExpanded,
                        onExpandedChange = { partDropdownExpanded = !partDropdownExpanded },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = selectedPart?.let { "${it.name} (${it.stock} ${it.unit})" } ?: "Pilih Part",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Pilih Sparepart") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = partDropdownExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth(),
                            colors = dialogTextFieldColors()
                        )
                        ExposedDropdownMenu(
                            expanded = partDropdownExpanded,
                            onDismissRequest = { partDropdownExpanded = false },
                            modifier = Modifier.background(Color(0xFF1E293B))
                        ) {
                            availableParts.forEach { part ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(part.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                                            Text(
                                                "${part.partCode} • Stok: ${part.stock} ${part.unit} • ${formatRupiah(part.unitPrice)}",
                                                color = Color(0xFF94A3B8),
                                                fontSize = 11.sp
                                            )
                                        }
                                    },
                                    onClick = {
                                        selectedPartId = part.id
                                        partDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    IconButton(
                        onClick = onOpenScanner,
                        modifier = Modifier
                            .size(52.dp)
                            .background(Color(0xFF334155), RoundedCornerShape(10.dp))
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan Barcode", tint = Color(0xFFF59E0B))
                    }
                }

                if (selectedPart != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Kode: ${selectedPart.partCode}", color = Color(0xFFF59E0B), fontSize = 11.sp)
                                Text("Lokasi: ${selectedPart.shelfLocation}", color = Color(0xFF94A3B8), fontSize = 11.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Tersedia: ${selectedPart.stock} ${selectedPart.unit}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(formatRupiah(selectedPart.unitPrice), color = Color(0xFF10B981), fontSize = 12.sp)
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = quantityStr,
                    onValueChange = { quantityStr = it },
                    label = { Text("Jumlah Dipakai (${selectedPart?.unit ?: "Pcs"})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("usage_quantity_input"),
                    colors = dialogTextFieldColors()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Posisi Pasang / Keterangan (e.g. Roda Kanan)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = dialogTextFieldColors()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedPartId == 0L) {
                        errorMessage = "Pilih sparepart terlebih dahulu"
                        return@Button
                    }
                    val qty = quantityStr.toIntOrNull() ?: 0
                    if (qty <= 0) {
                        errorMessage = "Jumlah part harus lebih dari 0"
                        return@Button
                    }
                    if (selectedPart != null && qty > selectedPart.stock) {
                        errorMessage = "Stok tidak mencukupi! Hanya ada ${selectedPart.stock} ${selectedPart.unit}"
                        return@Button
                    }

                    onSave(selectedPartId, qty, notes.trim())
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                modifier = Modifier.testTag("submit_part_usage_button")
            ) {
                Text("Pakai & Potong Stok", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        },
        containerColor = Color(0xFF1E293B),
        titleContentColor = Color.White,
        textContentColor = Color(0xFFCBD5E1)
    )
}
