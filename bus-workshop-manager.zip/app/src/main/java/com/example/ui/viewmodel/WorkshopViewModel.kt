package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.BusEntity
import com.example.data.local.entity.MechanicEntity
import com.example.data.local.entity.ServiceOrderEntity
import com.example.data.local.entity.SparepartEntity
import com.example.data.model.PartUsageDetail
import com.example.data.model.PartUsageSummary
import com.example.data.model.WorkshopStats
import com.example.data.repository.WorkshopRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppNavTab(val title: String) {
    DASHBOARD("Beranda"),
    BUSES("Armada Bus"),
    SERVICES("Servis & SPK"),
    SPAREPARTS("Sparepart"),
    REPORTS("Rekap & Mekanik"),
    BACKUP("Cadangan Data")
}

sealed class UiEvent {
    data class ShowSnackbar(val message: String) : UiEvent()
}

class WorkshopViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getInstance(application)
    val repository = WorkshopRepository(database)

    // Current Nav Screen
    private val _currentTab = MutableStateFlow(AppNavTab.DASHBOARD)
    val currentTab: StateFlow<AppNavTab> = _currentTab.asStateFlow()

    fun selectTab(tab: AppNavTab) {
        _currentTab.value = tab
    }

    // UI Event messages
    private val _uiEvent = MutableSharedFlow<UiEvent>()
    val uiEvent = _uiEvent.asSharedFlow()

    // Workshop Stats
    val stats: StateFlow<WorkshopStats> = repository.getWorkshopStats()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), WorkshopStats())

    // -----------------------------------------------------
    // BUS STATE & ACTIONS
    // -----------------------------------------------------
    private val _busSearchQuery = MutableStateFlow("")
    val busSearchQuery = _busSearchQuery.asStateFlow()

    private val _busStatusFilter = MutableStateFlow("Semua")
    val busStatusFilter = _busStatusFilter.asStateFlow()

    val buses: StateFlow<List<BusEntity>> = combine(
        _busSearchQuery,
        _busStatusFilter,
        repository.getAllBuses()
    ) { query, status, allBuses ->
        allBuses.filter { bus ->
            val matchesQuery = query.isBlank() ||
                    bus.plateNumber.contains(query, ignoreCase = true) ||
                    bus.model.contains(query, ignoreCase = true) ||
                    bus.operatorName.contains(query, ignoreCase = true)

            val matchesStatus = status == "Semua" || bus.serviceStatus == status
            matchesQuery && matchesStatus
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setBusSearchQuery(query: String) {
        _busSearchQuery.value = query
    }

    fun setBusStatusFilter(status: String) {
        _busStatusFilter.value = status
    }

    fun saveBus(bus: BusEntity) {
        viewModelScope.launch {
            repository.saveBus(bus)
            _uiEvent.emit(UiEvent.ShowSnackbar("Data bus ${bus.plateNumber} berhasil disimpan"))
        }
    }

    fun deleteBus(id: Long) {
        viewModelScope.launch {
            repository.deleteBus(id)
            _uiEvent.emit(UiEvent.ShowSnackbar("Unit bus berhasil dihapus"))
        }
    }

    // -----------------------------------------------------
    // MECHANIC STATE & ACTIONS
    // -----------------------------------------------------
    val mechanics: StateFlow<List<MechanicEntity>> = repository.getAllMechanics()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun saveMechanic(mechanic: MechanicEntity) {
        viewModelScope.launch {
            repository.saveMechanic(mechanic)
            _uiEvent.emit(UiEvent.ShowSnackbar("Data mekanik ${mechanic.name} berhasil disimpan"))
        }
    }

    fun deleteMechanic(id: Long) {
        viewModelScope.launch {
            repository.deleteMechanic(id)
            _uiEvent.emit(UiEvent.ShowSnackbar("Mekanik berhasil dihapus"))
        }
    }

    // -----------------------------------------------------
    // SPAREPART STATE & ACTIONS
    // -----------------------------------------------------
    private val _partSearchQuery = MutableStateFlow("")
    val partSearchQuery = _partSearchQuery.asStateFlow()

    private val _partCategoryFilter = MutableStateFlow("Semua")
    val partCategoryFilter = _partCategoryFilter.asStateFlow()

    private val _partOnlyLowStock = MutableStateFlow(false)
    val partOnlyLowStock = _partOnlyLowStock.asStateFlow()

    val spareparts: StateFlow<List<SparepartEntity>> = combine(
        _partSearchQuery,
        _partCategoryFilter,
        _partOnlyLowStock,
        repository.getAllSpareparts()
    ) { query, category, onlyLowStock, allParts ->
        allParts.filter { part ->
            val matchesQuery = query.isBlank() ||
                    part.name.contains(query, ignoreCase = true) ||
                    part.partCode.contains(query, ignoreCase = true) ||
                    part.shelfLocation.contains(query, ignoreCase = true)

            val matchesCategory = category == "Semua" || part.category == category
            val matchesLowStock = !onlyLowStock || part.stock <= part.minStock

            matchesQuery && matchesCategory && matchesLowStock
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockParts: StateFlow<List<SparepartEntity>> = repository.getLowStockSpareparts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setPartSearchQuery(query: String) {
        _partSearchQuery.value = query
    }

    fun setPartCategoryFilter(category: String) {
        _partCategoryFilter.value = category
    }

    fun setPartOnlyLowStock(onlyLow: Boolean) {
        _partOnlyLowStock.value = onlyLow
    }

    fun saveSparepart(part: SparepartEntity) {
        viewModelScope.launch {
            repository.saveSparepart(part)
            _uiEvent.emit(UiEvent.ShowSnackbar("Sparepart ${part.name} berhasil disimpan"))
        }
    }

    fun adjustPartStock(id: Long, delta: Int) {
        viewModelScope.launch {
            repository.adjustStock(id, delta)
            _uiEvent.emit(UiEvent.ShowSnackbar("Stok berhasil diperbarui"))
        }
    }

    fun deleteSparepart(id: Long) {
        viewModelScope.launch {
            repository.deleteSparepart(id)
            _uiEvent.emit(UiEvent.ShowSnackbar("Sparepart berhasil dihapus"))
        }
    }

    // -----------------------------------------------------
    // SERVICE ORDER (SPK) STATE & ACTIONS
    // -----------------------------------------------------
    private val _serviceStatusFilter = MutableStateFlow("Semua")
    val serviceStatusFilter = _serviceStatusFilter.asStateFlow()

    val serviceOrders: StateFlow<List<ServiceOrderEntity>> = combine(
        _serviceStatusFilter,
        repository.getAllServiceOrders()
    ) { filter, allOrders ->
        when (filter) {
            "Semua" -> allOrders
            "Aktif" -> allOrders.filter { it.status != "Selesai" && it.status != "Batal" }
            else -> allOrders.filter { it.status == filter }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setServiceStatusFilter(status: String) {
        _serviceStatusFilter.value = status
    }

    fun saveServiceOrder(order: ServiceOrderEntity) {
        viewModelScope.launch {
            repository.saveServiceOrder(order)
            _uiEvent.emit(UiEvent.ShowSnackbar("SPK ${order.spkNumber} berhasil disimpan"))
        }
    }

    fun completeServiceOrder(orderId: Long, repairNotes: String) {
        viewModelScope.launch {
            repository.completeServiceOrder(orderId, repairNotes)
            _uiEvent.emit(UiEvent.ShowSnackbar("SPK berhasil diselesaikan. Status bus kini Siap Jalan."))
        }
    }

    fun deleteServiceOrder(id: Long) {
        viewModelScope.launch {
            repository.deleteServiceOrder(id)
            _uiEvent.emit(UiEvent.ShowSnackbar("SPK berhasil dihapus"))
        }
    }

    // -----------------------------------------------------
    // PART USAGE STATE & ACTIONS
    // -----------------------------------------------------
    private val _selectedOrderIdForDetails = MutableStateFlow<Long?>(null)
    val selectedOrderIdForDetails = _selectedOrderIdForDetails.asStateFlow()

    fun selectServiceOrderForDetails(orderId: Long?) {
        _selectedOrderIdForDetails.value = orderId
    }

    val selectedOrderPartUsages: StateFlow<List<PartUsageDetail>> = _selectedOrderIdForDetails
        .flatMapLatest { orderId ->
            if (orderId != null) {
                repository.getUsageDetailsByServiceOrder(orderId)
            } else {
                kotlinx.coroutines.flow.flowOf(emptyList())
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun recordPartUsage(
        serviceOrderId: Long,
        sparepartId: Long,
        busId: Long,
        quantity: Int,
        notes: String
    ) {
        viewModelScope.launch {
            val result = repository.recordPartUsage(
                serviceOrderId = serviceOrderId,
                sparepartId = sparepartId,
                busId = busId,
                quantity = quantity,
                notes = notes
            )
            if (result.isSuccess) {
                _uiEvent.emit(UiEvent.ShowSnackbar("Pemakaian part dicatat & stok gudang otomatis berkurang"))
            } else {
                _uiEvent.emit(UiEvent.ShowSnackbar(result.exceptionOrNull()?.message ?: "Gagal mencatat part"))
            }
        }
    }

    fun removePartUsage(usageId: Long) {
        viewModelScope.launch {
            repository.removePartUsage(usageId)
            _uiEvent.emit(UiEvent.ShowSnackbar("Pemakaian part dibatalkan & stok dikembalikan ke gudang"))
        }
    }

    // -----------------------------------------------------
    // BARCODE SCANNER INTEGRATION
    // -----------------------------------------------------
    private val _isScannerActive = MutableStateFlow(false)
    val isScannerActive = _isScannerActive.asStateFlow()

    private val _scannedBarcode = MutableStateFlow<String?>(null)
    val scannedBarcode = _scannedBarcode.asStateFlow()

    fun startBarcodeScanner() {
        _scannedBarcode.value = null
        _isScannerActive.value = true
    }

    fun stopBarcodeScanner() {
        _isScannerActive.value = false
    }

    fun onBarcodeScanned(code: String) {
        _isScannerActive.value = false
        _scannedBarcode.value = code
        viewModelScope.launch {
            val foundPart = repository.getSparepartByCode(code)
            if (foundPart != null) {
                _uiEvent.emit(UiEvent.ShowSnackbar("Barcode ditemukan: ${foundPart.name} (${foundPart.stock} ${foundPart.unit})"))
            } else {
                _uiEvent.emit(UiEvent.ShowSnackbar("Barcode '$code' belum terdaftar di gudang"))
            }
        }
    }

    fun clearScannedBarcode() {
        _scannedBarcode.value = null
    }

    // -----------------------------------------------------
    // REPORTING & REKAP
    // -----------------------------------------------------
    private val _reportDateRangeDays = MutableStateFlow(30) // 7, 30, 90, 365
    val reportDateRangeDays = _reportDateRangeDays.asStateFlow()

    fun setReportDateRange(days: Int) {
        _reportDateRangeDays.value = days
    }

    val reportPartSummaries: StateFlow<List<PartUsageSummary>> = _reportDateRangeDays.flatMapLatest { days ->
        val now = System.currentTimeMillis()
        val start = if (days == 0) 0L else now - (days.toLong() * 24 * 60 * 60 * 1000)
        repository.getPartUsageSummaries(start, now)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reportTotalExpense: StateFlow<Double> = _reportDateRangeDays.flatMapLatest { days ->
        val now = System.currentTimeMillis()
        val start = if (days == 0) 0L else now - (days.toLong() * 24 * 60 * 60 * 1000)
        repository.getTotalPartExpenses(start, now)
    }.combine(MutableStateFlow(0.0)) { total, _ ->
        total ?: 0.0
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Bus history query
    private val _selectedBusForHistory = MutableStateFlow<Long?>(null)
    val selectedBusForHistory = _selectedBusForHistory.asStateFlow()

    fun selectBusForHistory(busId: Long?) {
        _selectedBusForHistory.value = busId
    }

    val busHistoryOrders: StateFlow<List<ServiceOrderEntity>> = _selectedBusForHistory.flatMapLatest { busId ->
        if (busId != null) {
            repository.getServiceOrdersByBus(busId)
        } else {
            kotlinx.coroutines.flow.flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val busHistoryPartsUsed: StateFlow<List<PartUsageDetail>> = _selectedBusForHistory.flatMapLatest { busId ->
        if (busId != null) {
            repository.getUsageDetailsByBus(busId)
        } else {
            kotlinx.coroutines.flow.flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // -----------------------------------------------------
    // BACKUP & RESTORE DATA
    // -----------------------------------------------------
    fun exportBackup(onResult: (String) -> Unit) {
        viewModelScope.launch {
            val json = repository.exportToJson()
            onResult(json)
            _uiEvent.emit(UiEvent.ShowSnackbar("Data cadangan bengkel bus berhasil disiapkan"))
        }
    }

    fun restoreBackup(jsonString: String, replaceAll: Boolean = true) {
        viewModelScope.launch {
            val result = repository.importFromJson(jsonString, replaceAll)
            if (result.isSuccess) {
                _uiEvent.emit(UiEvent.ShowSnackbar(result.getOrNull() ?: "Data berhasil dipulihkan"))
            } else {
                _uiEvent.emit(UiEvent.ShowSnackbar(result.exceptionOrNull()?.message ?: "Gagal memulihkan data"))
            }
        }
    }

    fun seedSampleData() {
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
            _uiEvent.emit(UiEvent.ShowSnackbar("Data contoh bengkel bus berhasil dimuat"))
        }
    }

    init {
        // Automatically seed demo data on first launch
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
        }
    }
}
