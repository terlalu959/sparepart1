package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatRupiah(amount: Double): String {
    val format = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
    format.maximumFractionDigits = 0
    return format.format(amount)
}

fun formatDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID"))
    return sdf.format(Date(timestamp))
}

fun formatDateShort(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM yyyy", Locale("id", "ID"))
    return sdf.format(Date(timestamp))
}

@Composable
fun BusStatusBadge(status: String, modifier: Modifier = Modifier) {
    val (bgColor, textColor, borderColor) = when (status) {
        "Siap Jalan" -> Triple(Color(0xFF064E3B), Color(0xFF34D399), Color(0xFF059669))
        "Dalam Perbaikan" -> Triple(Color(0xFF78350F), Color(0xFFFBBF24), Color(0xFFD97706))
        "Perlu Servis" -> Triple(Color(0xFF7C2D12), Color(0xFFFB923C), Color(0xFFEA580C))
        "Perbaikan Berat" -> Triple(Color(0xFF7F1D1D), Color(0xFFF87171), Color(0xFFDC2626))
        else -> Triple(Color(0xFF1E293B), Color(0xFF94A3B8), Color(0xFF475569))
    }

    Box(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(8.dp))
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = status,
            color = textColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun SpkStatusBadge(status: String, modifier: Modifier = Modifier) {
    val (bgColor, textColor, borderColor) = when (status) {
        "Selesai" -> Triple(Color(0xFF064E3B), Color(0xFF34D399), Color(0xFF059669))
        "Dikerjakan" -> Triple(Color(0xFF1E3A8A), Color(0xFF60A5FA), Color(0xFF2563EB))
        "Menunggu Part" -> Triple(Color(0xFF78350F), Color(0xFFFBBF24), Color(0xFFD97706))
        "Batal" -> Triple(Color(0xFF4B5563), Color(0xFF9CA3AF), Color(0xFF6B7280))
        else -> Triple(Color(0xFF1E293B), Color(0xFF94A3B8), Color(0xFF475569))
    }

    Box(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(8.dp))
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = status,
            color = textColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun StockBadge(stock: Int, minStock: Int, unit: String, modifier: Modifier = Modifier) {
    val isCritical = stock <= 0
    val isLow = stock <= minStock && !isCritical

    val (bgColor, textColor) = when {
        isCritical -> Pair(Color(0xFF7F1D1D), Color(0xFFFCA5A5))
        isLow -> Pair(Color(0xFF78350F), Color(0xFFFDE68A))
        else -> Pair(Color(0xFF064E3B), Color(0xFFA7F3D0))
    }

    val label = when {
        isCritical -> "HABIS (0 $unit)"
        isLow -> "STOK TIPIS ($stock $unit)"
        else -> "Stok: $stock $unit"
    }

    Box(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = label,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
