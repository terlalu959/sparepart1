package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.BarcodeScannerModal
import com.example.ui.screens.AddEditBusDialog
import com.example.ui.screens.AddEditServiceOrderDialog
import com.example.ui.screens.AddEditSparepartDialog
import com.example.ui.screens.BusScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.ReportsAndMechanicsScreen
import com.example.ui.screens.ServiceScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.UiEvent
import com.example.ui.viewmodel.WorkshopViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                BengkelBusMainApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BengkelBusMainApp(
    viewModel: WorkshopViewModel = viewModel()
) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val isScannerActive by viewModel.isScannerActive.collectAsStateWithLifecycle()
    val stats by viewModel.stats.collectAsStateWithLifecycle()

    val allBuses by viewModel.buses.collectAsStateWithLifecycle()
    val allMechanics by viewModel.mechanics.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    // Dialog state controllers accessible globally
    var showAddBusDialog by remember { mutableStateOf(false) }
    var showAddSpkDialog by remember { mutableStateOf(false) }
    var showAddPartDialog by remember { mutableStateOf(false) }

    // Selected items for navigation jump
    var jumpToSpkId by remember { mutableStateOf<Long?>(null) }
    var jumpToBusIdHistory by remember { mutableStateOf<Long?>(null) }

    // Listen to UI Events (Snackbar)
    LaunchedEffect(key1 = true) {
        viewModel.uiEvent.collect { event ->
            when (event) {
                is UiEvent.ShowSnackbar -> {
                    snackbarHostState.showSnackbar(event.message)
                }
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color(0xFF0B1120),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(Color(0xFFF59E0B), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.DirectionsBus,
                                contentDescription = null,
                                tint = Color(0xFF0F172A),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "BengkelBus App",
                                color = Color.White,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(Color(0xFF10B981), CircleShape)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "100% Offline Database",
                                    color = Color(0xFF10B981),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                },
                actions = {
                    // Top Bar Scanner Button
                    IconButton(
                        onClick = { viewModel.startBarcodeScanner() },
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .background(Color(0xFF1E293B), RoundedCornerShape(10.dp))
                            .border(1.dp, Color(0xFFF59E0B).copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                            .testTag("top_bar_scanner_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = "Pindai Barcode",
                            tint = Color(0xFFF59E0B),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color(0xFF111827)
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0F172A),
                contentColor = Color(0xFF94A3B8)
            ) {
                // 1. Dashboard Tab
                NavigationBarItem(
                    selected = currentTab == AppNavTab.DASHBOARD,
                    onClick = { viewModel.selectTab(AppNavTab.DASHBOARD) },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Beranda") },
                    label = { Text("Beranda", fontSize = 11.sp) },
                    colors = workshopNavColors(),
                    modifier = Modifier.testTag("nav_tab_dashboard")
                )

                // 2. Armada Bus Tab
                NavigationBarItem(
                    selected = currentTab == AppNavTab.BUSES,
                    onClick = { viewModel.selectTab(AppNavTab.BUSES) },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (stats.inWorkshopBuses > 0) {
                                    Badge(
                                        containerColor = Color(0xFFF59E0B),
                                        contentColor = Color(0xFF0F172A)
                                    ) {
                                        Text("${stats.inWorkshopBuses}")
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Default.DirectionsBus, contentDescription = "Armada")
                        }
                    },
                    label = { Text("Armada", fontSize = 11.sp) },
                    colors = workshopNavColors(),
                    modifier = Modifier.testTag("nav_tab_buses")
                )

                // 3. Servis & SPK Tab
                NavigationBarItem(
                    selected = currentTab == AppNavTab.SERVICES,
                    onClick = {
                        jumpToSpkId = null
                        viewModel.selectTab(AppNavTab.SERVICES)
                    },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (stats.activeServiceOrders > 0) {
                                    Badge(
                                        containerColor = Color(0xFF38BDF8),
                                        contentColor = Color(0xFF0F172A)
                                    ) {
                                        Text("${stats.activeServiceOrders}")
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Default.Build, contentDescription = "Servis")
                        }
                    },
                    label = { Text("Servis", fontSize = 11.sp) },
                    colors = workshopNavColors(),
                    modifier = Modifier.testTag("nav_tab_services")
                )

                // 4. Sparepart Tab
                NavigationBarItem(
                    selected = currentTab == AppNavTab.SPAREPARTS,
                    onClick = { viewModel.selectTab(AppNavTab.SPAREPARTS) },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (stats.lowStockPartsCount > 0) {
                                    Badge(
                                        containerColor = Color(0xFFEF4444),
                                        contentColor = Color.White
                                    ) {
                                        Text("${stats.lowStockPartsCount}")
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Default.Inventory2, contentDescription = "Gudang Part")
                        }
                    },
                    label = { Text("Sparepart", fontSize = 11.sp) },
                    colors = workshopNavColors(),
                    modifier = Modifier.testTag("nav_tab_spareparts")
                )

                // 5. Rekap & Laporan Tab
                NavigationBarItem(
                    selected = currentTab == AppNavTab.REPORTS,
                    onClick = {
                        jumpToBusIdHistory = null
                        viewModel.selectTab(AppNavTab.REPORTS)
                    },
                    icon = { Icon(Icons.Default.Assessment, contentDescription = "Laporan") },
                    label = { Text("Laporan", fontSize = 11.sp) },
                    colors = workshopNavColors(),
                    modifier = Modifier.testTag("nav_tab_reports")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                AppNavTab.DASHBOARD -> {
                    DashboardScreen(
                        viewModel = viewModel,
                        onOpenAddSpk = { showAddSpkDialog = true },
                        onOpenAddBus = { showAddBusDialog = true },
                        onOpenAddPart = { showAddPartDialog = true },
                        onOpenScanner = { viewModel.startBarcodeScanner() },
                        onOpenSpkDetail = { spkId ->
                            jumpToSpkId = spkId
                            viewModel.selectTab(AppNavTab.SERVICES)
                        }
                    )
                }

                AppNavTab.BUSES -> {
                    BusScreen(
                        viewModel = viewModel,
                        onViewBusHistory = { busId ->
                            jumpToBusIdHistory = busId
                            viewModel.selectBusForHistory(busId)
                            viewModel.selectTab(AppNavTab.REPORTS)
                        }
                    )
                }

                AppNavTab.SERVICES -> {
                    ServiceScreen(
                        viewModel = viewModel,
                        preselectedOrderId = jumpToSpkId,
                        onOpenScanner = { viewModel.startBarcodeScanner() }
                    )
                }

                AppNavTab.SPAREPARTS -> {
                    InventoryScreen(
                        viewModel = viewModel,
                        onOpenScanner = { viewModel.startBarcodeScanner() }
                    )
                }

                AppNavTab.REPORTS, AppNavTab.BACKUP -> {
                    ReportsAndMechanicsScreen(
                        viewModel = viewModel,
                        preselectedBusIdForHistory = jumpToBusIdHistory
                    )
                }
            }
        }
    }

    // ==========================================
    // BARCODE SCANNER MODAL (CameraX + ZXing)
    // ==========================================
    AnimatedVisibility(
        visible = isScannerActive,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        BarcodeScannerModal(
            onDismiss = { viewModel.stopBarcodeScanner() },
            onBarcodeScanned = { scannedCode ->
                viewModel.onBarcodeScanned(scannedCode)
            }
        )
    }

    // Global Add Bus Dialog
    if (showAddBusDialog) {
        AddEditBusDialog(
            bus = null,
            onDismiss = { showAddBusDialog = false },
            onSave = { bus ->
                viewModel.saveBus(bus)
                showAddBusDialog = false
            }
        )
    }

    // Global Add SPK Dialog
    if (showAddSpkDialog) {
        AddEditServiceOrderDialog(
            order = null,
            buses = allBuses,
            mechanics = allMechanics,
            onDismiss = { showAddSpkDialog = false },
            onSave = { order ->
                viewModel.saveServiceOrder(order)
                showAddSpkDialog = false
            }
        )
    }

    // Global Add Sparepart Dialog
    if (showAddPartDialog) {
        AddEditSparepartDialog(
            part = null,
            prefilledBarcode = null,
            onDismiss = { showAddPartDialog = false },
            onOpenScanner = { viewModel.startBarcodeScanner() },
            onSave = { part ->
                viewModel.saveSparepart(part)
                showAddPartDialog = false
            }
        )
    }
}

@Composable
fun workshopNavColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = Color(0xFF0F172A),
    selectedTextColor = Color(0xFFF59E0B),
    indicatorColor = Color(0xFFF59E0B),
    unselectedIconColor = Color(0xFF94A3B8),
    unselectedTextColor = Color(0xFF64748B)
)
